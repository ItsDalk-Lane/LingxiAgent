import { useStore } from './index';
import { resolveServerConnection, type ServerConnectionSource } from '../services/server-connection';
import { sessionScopedKey, sessionScopedValue, type SessionLocatorState } from './session-slice';

export interface BrowserSessionState {
  executionNode?: string;
  /** 仅含公开连接坐标，用于快照清理时核对当前资料归属。 */
  connectionScope?: string;
  running: boolean;
  url: string | null;
  thumbnail: string | null;
  thumbnailCapturedAt?: number | null;
  thumbnailUrl?: string | null;
  thumbnailFresh?: boolean;
  /** 聊天区浮动卡片被用户收起。纯前端展示状态，不影响浏览器本身是否运行。 */
  collapsed?: boolean;
  /** 最近一次有活动（状态上报）的时间戳，用于跨会话显示时挑出"最近在用"的浏览器。 */
  lastActiveAt?: number | null;
  /** 该浏览器归属的会话路径（map 的键可能是 sessionId，不能直接当路径用）。 */
  sessionPath?: string | null;
}

export interface BrowserSlice {
  /** 按 session identity 存储的 browser 状态。legacy path key 只做读时兼容。 */
  browserBySession: Record<string, BrowserSessionState>;
}

export const createBrowserSlice = (
  set: (partial: Partial<BrowserSlice>) => void
): BrowserSlice => ({
  browserBySession: {},
});

// ── Selector hook ──

const DEFAULT_BROWSER_STATE = {
  running: false,
  url: null as string | null,
  thumbnail: null as string | null,
  thumbnailCapturedAt: null as number | null,
  thumbnailUrl: null as string | null,
  thumbnailFresh: false,
  collapsed: false,
};

export function browserConnectionScope(state: ServerConnectionSource): string {
  const connection = resolveServerConnection(state);
  return JSON.stringify(connection ? [connection.connectionId, connection.kind, connection.baseUrl, connection.serverId, connection.serverNodeId, connection.userId, connection.studioId] : null);
}

export function browserStateForPath(
  state: SessionLocatorState & Pick<BrowserSlice, 'browserBySession'> & ServerConnectionSource,
  sessionPath?: string | null,
): BrowserSessionState {
  const sp = sessionPath ?? state.currentSessionPath;
  if (!sp) return DEFAULT_BROWSER_STATE;
  const value = sessionScopedValue(state, state.browserBySession, sp);
  const connection = resolveServerConnection(state);
  if (connection?.serverNodeKind === 'lingxi-service' && (value?.executionNode !== connection.serverId || (value.connectionScope !== undefined && value.connectionScope !== browserConnectionScope(state)))) return DEFAULT_BROWSER_STATE;
  return value || DEFAULT_BROWSER_STATE;
}

export function setBrowserStateForPath(
  sessionPath: string,
  value: BrowserSessionState,
): void {
  useStore.setState((state) => {
    const connection = resolveServerConnection(state);
    if (connection?.serverNodeKind === 'lingxi-service' && (!sessionPath.startsWith('native:') || value.executionNode !== connection.serverId)) return {};
    const key = sessionScopedKey(state, sessionPath) || sessionPath;
    // 把归属会话路径一并存进值里：map 键可能是 sessionId，跨会话显示时仍要能拿到真实路径。
    const browserBySession = { ...(state.browserBySession || {}), [key]: { ...value, sessionPath, ...(connection?.serverNodeKind === 'lingxi-service' ? { connectionScope: browserConnectionScope(state) } : {}) } };
    if (key !== sessionPath) delete browserBySession[sessionPath];
    return { browserBySession };
  });
}

/**
 * 收起 / 展开聊天区的浏览器浮动卡片。合并写：只改 collapsed，其它字段沿用当前记录，
 * 这样"收起卡片"不会顺带擦掉 url / 缩略图等运行时状态。
 */
export function setBrowserCardCollapsed(sessionPath: string, collapsed: boolean): void {
  useStore.setState((state) => {
    const key = sessionScopedKey(state, sessionPath) || sessionPath;
    const prev = sessionScopedValue(state, state.browserBySession, sessionPath) || DEFAULT_BROWSER_STATE;
    const browserBySession = { ...(state.browserBySession || {}), [key]: { ...prev, collapsed, sessionPath } };
    if (key !== sessionPath) delete browserBySession[sessionPath];
    return { browserBySession };
  });
}

export function clearBrowserStateForPath(sessionPath: string): void {
  useStore.setState((state) => {
    const key = sessionScopedKey(state, sessionPath) || sessionPath;
    const browserBySession = { ...(state.browserBySession || {}) };
    delete browserBySession[key];
    if (key !== sessionPath) delete browserBySession[sessionPath];
    return { browserBySession };
  });
}

/** 获取指定 session 的浏览器状态。组件中使用此 hook 替代全局 browserRunning/browserUrl/browserThumbnail */
export function useBrowserState(sessionPath?: string | null) {
  return useStore(st => {
    return browserStateForPath(st, sessionPath);
  });
}

/** 判断是否有任何 session 的浏览器正在运行 */
export function useAnyBrowserRunning() {
  return useStore(st => Object.values(st.browserBySession).some(b => b.running));
}
