/**
 * @vitest-environment jsdom
 */
import { afterEach, describe, expect, it, vi } from 'vitest';

const lingxiFetch = vi.hoisted(() => vi.fn(async (path: string) => ({
  json: async () => (path.endsWith('/subscribe') ? { ok: true, subscriptionId: 'sub-1' } : { ok: true }),
})));

vi.mock('../../hooks/use-hana-fetch', () => ({ lingxiFetch }));

describe('resource-events', () => {
  afterEach(() => {
    vi.resetModules();
    lingxiFetch.mockClear();
  });

  it('shares one backend resource subscription per local file and releases it after the last subscriber leaves', async () => {
    const { retainLocalFileResourceWatch } = await import('../../services/resource-events');

    const releaseFirst = retainLocalFileResourceWatch('/tmp/note.md');
    const releaseSecond = retainLocalFileResourceWatch('/tmp/note.md');
    await Promise.resolve();

    expect(lingxiFetch).toHaveBeenCalledTimes(1);
    expect(lingxiFetch).toHaveBeenCalledWith('/api/resource-io/subscribe', expect.objectContaining({
      method: 'POST',
      body: JSON.stringify({
        purpose: 'resource-watch',
        resources: [{ kind: 'local-file', path: '/tmp/note.md' }],
      }),
    }));

    releaseFirst();
    await Promise.resolve();
    expect(lingxiFetch).toHaveBeenCalledTimes(1);

    releaseSecond();
    await Promise.resolve();
    await Promise.resolve();

    expect(lingxiFetch).toHaveBeenCalledWith('/api/resource-io/subscriptions/sub-1', expect.objectContaining({
      method: 'DELETE',
    }));
  });

  it('dedupes mount ResourceRefs without materializing native paths in the renderer', async () => {
    const { retainResourceWatch } = await import('../../services/resource-events');

    const releaseFirst = retainResourceWatch({ kind: 'mount', mountId: 'mount_docs', path: 'notes' });
    const releaseSecond = retainResourceWatch({ kind: 'mount', mountId: 'mount_docs', path: 'notes/' });
    await Promise.resolve();

    expect(lingxiFetch).toHaveBeenCalledTimes(1);
    expect(lingxiFetch).toHaveBeenCalledWith('/api/resource-io/subscribe', expect.objectContaining({
      method: 'POST',
      body: JSON.stringify({
        purpose: 'resource-watch',
        resources: [{ kind: 'mount', mountId: 'mount_docs', path: 'notes' }],
      }),
    }));

    releaseFirst();
    releaseSecond();
  });

  it('learns the server-resolved path alias of a watched local path', async () => {
    lingxiFetch.mockImplementation(async (path: string) => ({
      json: async () => (path.endsWith('/subscribe')
        ? { ok: true, subscriptionId: 'sub-alias', resourceKeys: ['local_fs:/private/tmp/ws'] }
        : { ok: true }),
    }));
    const { retainResourceWatch, resolvedLocalPathAlias } = await import('../../services/resource-events');

    const release = retainResourceWatch({ kind: 'local-file', path: '/tmp/ws' });
    expect(resolvedLocalPathAlias('/tmp/ws')).toBeNull();

    await new Promise(resolve => setTimeout(resolve, 0));

    // macOS：/tmp 是 /private/tmp 的符号链接，服务端 realpath 后只回解析路径。
    expect(resolvedLocalPathAlias('/tmp/ws')).toBe('/private/tmp/ws');
    // 已经解析过的路径没有别名，避免调用方拿到重复基准。
    expect(resolvedLocalPathAlias('/private/tmp/ws')).toBeNull();

    release();
  });

  it('requests catch-up after reconnect with the last seen resource event sequence', async () => {
    const fetchImpl = vi.fn(async () => ({
      ok: true,
      json: async () => ({ stale: false, latestSequence: 5, events: [] }),
    }));
    const { createResourceEventClient } = await import('../../services/resource-events');
    const client = createResourceEventClient({ fetchImpl });

    client.handleEvent({
      type: 'resource.changed',
      sequence: 4,
      resourceKey: 'local_fs:/tmp/a.md',
      resource: { kind: 'local-file', path: '/tmp/a.md' },
      changeType: 'modified',
      source: 'api',
      occurredAt: '2026-06-22T00:00:00.000Z',
    });
    await client.catchUpAfterReconnect();

    expect(fetchImpl).toHaveBeenCalledWith('/api/resource-io/events?since=4', expect.objectContaining({
      method: 'GET',
      throwOnHttpError: false,
    }));
  });

  it('服务资源日志重启归零时重建订阅并重置游标，不能一直请求旧序号', async () => {
    const fetchImpl = vi.fn(async () => ({ json: async () => ({ stale: false, latestSequence: 0, events: [] }) }));
    const resubscribeWatches = vi.fn(async () => {});
    const { createResourceEventClient } = await import('../../services/resource-events');
    const client = createResourceEventClient({ fetchImpl, resubscribeWatches });
    client.handleEvent({ type: 'resource.changed', sequence: 100 });
    await client.catchUpAfterReconnect();
    expect(resubscribeWatches).toHaveBeenCalledOnce();
    expect(client.lastSeenSequence()).toBe(0);
    await client.catchUpAfterReconnect();
    expect(fetchImpl).toHaveBeenLastCalledWith('/api/resource-io/events?since=0', expect.any(Object));
  });

  it('applies caught-up resource events through the same event handler', async () => {
    const event = {
      type: 'resource.changed',
      sequence: 6,
      resourceKey: 'local_fs:/tmp/b.md',
      resource: { kind: 'local-file', path: '/tmp/b.md' },
      changeType: 'modified',
      source: 'provider_watch',
      occurredAt: '2026-06-22T00:00:01.000Z',
    };
    const applyEvent = vi.fn();
    const fetchImpl = vi.fn(async () => ({
      ok: true,
      json: async () => ({ stale: false, latestSequence: 6, events: [event] }),
    }));
    const { createResourceEventClient } = await import('../../services/resource-events');
    const client = createResourceEventClient({ fetchImpl, applyEvent });

    await client.catchUpAfterReconnect();

    expect(applyEvent).toHaveBeenCalledWith(event);
    expect(client.lastSeenSequence()).toBe(6);
  });

  it('requests ResourceIO catch-up when the renderer returns to the foreground', async () => {
    const listeners = new Map<string, () => void>();
    const windowObj = {
      addEventListener: vi.fn((type: string, listener: () => void) => listeners.set(`window:${type}`, listener)),
      removeEventListener: vi.fn(),
    };
    let visibilityState: Document['visibilityState'] = 'hidden';
    const documentObj = {
      addEventListener: vi.fn((type: string, listener: () => void) => listeners.set(`document:${type}`, listener)),
      removeEventListener: vi.fn(),
      get visibilityState() {
        return visibilityState;
      },
    };
    const catchUp = vi.fn(async () => undefined);
    const { bindResourceEventForegroundCatchUp } = await import('../../services/resource-events');

    const dispose = bindResourceEventForegroundCatchUp(undefined, {
      windowObj: windowObj as never,
      documentObj: documentObj as never,
      catchUp,
      minIntervalMs: 0,
      now: () => 100,
    });

    listeners.get('window:focus')?.();
    expect(catchUp).not.toHaveBeenCalled();

    visibilityState = 'visible';
    listeners.get('document:visibilitychange')?.();
    await Promise.resolve();

    expect(catchUp).toHaveBeenCalledTimes(1);
    dispose();
    expect(windowObj.removeEventListener).toHaveBeenCalledWith('focus', expect.any(Function));
    expect(documentObj.removeEventListener).toHaveBeenCalledWith('visibilitychange', expect.any(Function));
  });
});
