import { applyBrowserStatus } from './browser-events';
/**
 * ws-message-handler.ts — WebSocket 消息分发（从 app-ws-shim.ts 迁移）
 *
 * 纯逻辑模块，不依赖 ctx 注入。通过 Zustand store 访问状态。
 */

/* eslint-disable @typescript-eslint/no-explicit-any -- WS 消息分发，msg 结构由服务端动态决定 */

import { streamBufferManager } from '../hooks/use-stream-buffer';
import { dispatchStreamKey } from './stream-key-dispatcher';
import { getWebSocket } from './websocket';
import { useStore } from '../stores';
import { updateKeyed } from '../stores/create-keyed-slice';
import { sessionScopedKey, sessionScopedListIncludes, sessionScopedValue } from '../stores/session-slice';
import { browserStateForPath, setBrowserStateForPath } from '../stores/browser-slice';
import { scheduleSessionsRefresh } from './session-refresh-scheduler';
import { handleLegacyArtifactBlock } from '../stores/preview-actions';
import { handleConversationEvent } from './conversation-events';
import { showError } from '../utils/ui-helpers';
import { errorWithCode, presentError } from '../errors/error-presenter';
import { handleAppEvent } from './app-event-actions';
import { readLoopRuntimeError, warnLoopRuntimeError } from './loop-runtime-error';
import { openSettingsModal } from '../stores/settings-modal-actions';
import {
  PREVIEW_DOCUMENT_CHANGE_REFRESH_OPTIONS,
  markDeskTreeDirtyForResourceChange,
  refreshOpenPreviewDocumentsForResourceChange,
} from '../utils/preview-document-refresh';
import {
  replayStreamResume,
  isStreamResumeRebuilding,
  isStreamScopedMessage,
  updateSessionStreamMeta,
} from './stream-resume';
import { TODO_TOOL_NAMES, type TodoToolName } from '../utils/todo-constants';
import { migrateLegacyTodos, panelSnapshotFromToolDetails } from '../utils/todo-compat';
import { extractLeadingSkillNotes } from '../utils/message-parser';
import { renderMarkdown } from '../utils/markdown';
import { bumpMessageLiveVersion } from '../stores/message-live-version';
import { terminalOutputStream } from './terminal-output-stream';
import { handleBackgroundProcessControlResult } from './background-process-control';
import { noteComposerServerAck, noteComposerRunEvent, noteComposerInputRejected, noteComposerUserAbort, extendComposerAckWindow, composerOriginConnectionKey, findSendRecordByClientMessageId } from './composer-send-coordinator';

declare function t(key: string, vars?: Record<string, string>): any;

let requestContextUsage: (sessionPath: string) => void = () => {};

function syncSessionPermissionMode(mode: unknown) {
  if (mode === 'auto' || mode === 'operate' || mode === 'ask' || mode === 'read_only') {
    useStore.getState().setSessionPermissionMode?.(mode);
  }
}

function nonEmptyString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

// 高频事件（terminal_output）的身份告警节流：同一 key 每分钟最多一条，
// 否则一条错配流会把 console 刷满。
const IDENTITY_WARN_THROTTLE_MS = 60_000;
const identityWarnLastAt = new Map<string, number>();

function throttledIdentityWarn(key: string, message: string, details: unknown): void {
  const now = Date.now();
  if (now - (identityWarnLastAt.get(key) ?? -Infinity) < IDENTITY_WARN_THROTTLE_MS) return;
  identityWarnLastAt.set(key, now);
  console.warn(message, details);
}

function sessionIdentityFromMessage(msg: any): { sessionId: string | null; sessionPath: string | null } {
  const session = msg?.session && typeof msg.session === 'object' ? msg.session : null;
  return {
    sessionId: nonEmptyString(msg?.sessionId) || nonEmptyString(session?.sessionId),
    sessionPath: nonEmptyString(msg?.sessionPath) || nonEmptyString(msg?.path) || nonEmptyString(session?.path),
  };
}

function rememberSessionLocatorFromMessage(msg: any, { write = true }: { write?: boolean } = {}): boolean {
  const { sessionId, sessionPath } = sessionIdentityFromMessage(msg);
  if (!sessionId || !sessionPath) return true;
  if (
    msg?.type === 'compaction_accepted'
    || msg?.type === 'compaction_result'
    || msg?.type === 'compaction_start'
    || msg?.type === 'compaction_end'
  ) {
    // Compaction path is transport metadata only. Identity routing uses sessionId,
    // and this event family must never mutate the locator truth maintained by the
    // sessions projection / manifest boundary.
    return true;
  }
  const snapshot = useStore.getState();
  const knownLocatorPath = snapshot.sessionLocatorsById?.[sessionId]?.path || null;
  const authoritativeLocatorUpdate = msg?.type === 'session_created';
  if (knownLocatorPath && knownLocatorPath !== sessionPath && !authoritativeLocatorUpdate) {
    throttledIdentityWarn(`locator:${sessionId}:${sessionPath}`, '[ws] session locator mismatch; dropping non-authoritative event', {
      sessionId,
      sessionPath,
      knownLocatorPath,
    });
    return false;
  }
  const knownPathSessionId = snapshot.sessions.find((session: any) => session?.path === sessionPath)?.sessionId
    || (snapshot.currentSessionPath === sessionPath ? snapshot.currentSessionId : null)
    || Object.entries(snapshot.sessionLocatorsById || {}).find(([, locator]: any) => locator?.path === sessionPath)?.[0]
    || null;
  if (knownPathSessionId && knownPathSessionId !== sessionId) {
    throttledIdentityWarn(`identity:${sessionId}:${sessionPath}`, '[ws] session identity mismatch; dropping event', { sessionId, sessionPath, knownPathSessionId });
    return false;
  }
  if (!write) return true;
  useStore.setState((state: any) => {
    const currentLocator = state.sessionLocatorsById?.[sessionId] || null;
    const patch: Record<string, any> = {};
    if (currentLocator?.path !== sessionPath) {
      patch.sessionLocatorsById = {
        ...(state.sessionLocatorsById || {}),
        [sessionId]: { path: sessionPath },
      };
    }
    if (state.currentSessionPath === sessionPath && state.currentSessionId !== sessionId) {
      patch.currentSessionId = sessionId;
    }
    return Object.keys(patch).length ? patch : {};
  });
  return true;
}

function isFocusedSessionMessage(msg: any): boolean {
  const { sessionId, sessionPath } = sessionIdentityFromMessage(msg);
  if (!sessionId && !sessionPath) return true;
  const state = useStore.getState();
  if (sessionId && sessionPath) {
    return state.currentSessionPath === sessionPath && state.currentSessionId === sessionId;
  }
  return (!!sessionPath && state.currentSessionPath === sessionPath)
    || (!!sessionId && state.currentSessionId === sessionId);
}

export function configureWsMessageHandler(options: {
  requestContextUsage?: (sessionPath: string) => void;
}): void {
  requestContextUsage = options.requestContextUsage || (() => {});
}

// ── 聊天事件集合（走 StreamBufferManager） ──

const REACT_CHAT_EVENTS = new Set([
  // Assistant Run 生命周期（权威）：assistant_run_start / assistant_run_end。
  'assistant_run_start', 'assistant_run_end',
  // Pi Model Turn 边界（仅 diagnostics）：model_turn_start / model_turn_end；
  // turn_start / turn_end 是旧协议别名，兼容旧 server。
  'model_turn_start', 'model_turn_end', 'turn_start', 'turn_end',
  'assistant_segment_start', 'assistant_segment_delta', 'assistant_segment_end',
  'text_delta', 'thinking_start', 'thinking_delta', 'thinking_end',
  'mood_start', 'mood_text', 'mood_end',
  'tool_start', 'tool_end',
  'content_block',
  'compaction_start', 'compaction_end',
]);

// ── Session 可见性 + 流状态 ──

function ensureCurrentSessionVisible(): void {
  const state = useStore.getState();
  const sessionPath = state.currentSessionPath;
  if (!sessionPath || state.pendingNewSession) return;
  if (state.sessions.some((s: any) => s.path === sessionPath)) return;

  useStore.setState({
    sessions: [{
      path: sessionPath,
      title: null,
      firstMessage: '',
      modified: new Date().toISOString(),
      messageCount: 0,
      agentId: state.currentAgentId || null,
      agentName: state.agentName || null,
      cwd: null,
      _optimistic: true,
    }, ...state.sessions],
  });
}

function upsertCreatedSession(msg: any): void {
  const incoming = msg.session && typeof msg.session === 'object' ? msg.session : {};
  const sessionPath = typeof incoming.path === 'string' && incoming.path.trim()
    ? incoming.path
    : typeof msg.sessionPath === 'string' && msg.sessionPath.trim()
      ? msg.sessionPath
      : null;
  if (!sessionPath) return;
  const sessionId = typeof incoming.sessionId === 'string' && incoming.sessionId.trim()
    ? incoming.sessionId.trim()
    : typeof msg.sessionId === 'string' && msg.sessionId.trim()
      ? msg.sessionId.trim()
      : null;

  const state = useStore.getState();
  const existing: any = state.sessions.find((s: any) => s.path === sessionPath) || {};
  const now = new Date().toISOString();
  const next = {
    ...existing,
    path: sessionPath,
    sessionId: sessionId || existing.sessionId || null,
    title: typeof incoming.title === 'string' ? incoming.title : existing.title ?? null,
    firstMessage: typeof incoming.firstMessage === 'string' ? incoming.firstMessage : existing.firstMessage ?? '',
    modified: typeof incoming.modified === 'string' ? incoming.modified : existing.modified ?? now,
    messageCount: Number.isFinite(incoming.messageCount) ? incoming.messageCount : existing.messageCount ?? 0,
    agentId: typeof incoming.agentId === 'string' ? incoming.agentId : existing.agentId ?? state.currentAgentId ?? null,
    agentName: typeof incoming.agentName === 'string' ? incoming.agentName : existing.agentName ?? state.agentName ?? null,
    cwd: typeof incoming.cwd === 'string' ? incoming.cwd : existing.cwd ?? null,
    pinnedAt: incoming.pinnedAt ?? existing.pinnedAt ?? null,
    hasSummary: incoming.hasSummary ?? existing.hasSummary,
    rcAttachment: incoming.rcAttachment ?? existing.rcAttachment ?? null,
    _optimistic: false,
  };

  useStore.setState({
    sessions: [next, ...state.sessions.filter((s: any) => s.path !== sessionPath)]
      .sort((a: any, b: any) => new Date(b.modified || 0).getTime() - new Date(a.modified || 0).getTime()),
    ...(sessionId ? {
      sessionLocatorsById: {
        ...(state.sessionLocatorsById || {}),
        [sessionId]: { path: sessionPath },
      },
    } : {}),
  });
}

function resolveNotificationDesktopFocusPolicy(msg: any): 'always' | 'when_unfocused' {
  if (msg.desktopFocusPolicy === 'when_session_unfocused') {
    const completedSessionPath = typeof msg.sessionPath === 'string' && msg.sessionPath.trim()
      ? msg.sessionPath.trim()
      : null;
    const currentSessionPath = useStore.getState().currentSessionPath || null;
    if (completedSessionPath && currentSessionPath !== completedSessionPath) return 'always';
    return 'when_unfocused';
  }
  return msg.desktopFocusPolicy === 'when_unfocused' ? 'when_unfocused' : 'always';
}

function hasOptimisticCurrentSession(): boolean {
  const state = useStore.getState();
  const sessionPath = state.currentSessionPath;
  if (!sessionPath) return false;
  return !!state.sessions.find((s: any) => s.path === sessionPath && s._optimistic);
}


function applyTodoToolEnd(msg: any): void {
  if (msg.type !== 'tool_end' || !TODO_TOOL_NAMES.includes(msg.name as TodoToolName)) return;
  const sp = msg.sessionPath;
  if (!sp) {
    console.warn('[ws] tool_end(todo) missing sessionPath, skipping');
    return;
  }
  // 失败或数据损坏的结果绝不能转换为空清单（A13）：保留最后一份有效
  // 清单并标记更新失败。明确提交的空清单（details.todos = []）是合法
  // 快照，走正常清空路径，与失败严格区分（A14）。
  const snapshot = msg.success === false || msg.error
    ? null
    : panelSnapshotFromToolDetails(msg.details);
  if (!snapshot) {
    console.error('[ws] tool_end(todo) 更新失败或数据损坏，保留最后有效清单', {
      sessionPath: sp,
      success: msg.success,
      error: msg.error,
    });
    useStore.getState().markSessionTodoUpdateFailed(sp);
    useStore.getState().bumpTodosLiveVersion(sp);
    return;
  }
  useStore.getState().setSessionTodoPanel(sp, snapshot.removed ? null : { ...snapshot, updateFailed: false });
  // bump 版本：若 loadMessages 正在 fetch 旧快照，回来时会发现
  // 版本号变了，主动跳过 hydrate 写入，避免覆盖本次 live 状态。
  useStore.getState().bumpTodosLiveVersion(sp);
}

function isKnownChatSession(sessionPath: string, state = useStore.getState()): boolean {
  return !!sessionScopedValue(state, state.chatSessions, sessionPath)
    || state.sessions.some((s: any) => s.path === sessionPath);
}

function requestInputFocusForCurrentSession(sessionPath: string | null): void {
  if (!sessionPath) return;
  const state = useStore.getState();
  if (state.pendingNewSession) return;
  if (state.currentSessionPath !== sessionPath) return;
  state.requestInputFocus?.('restore');
}

function applyRunEndSideEffects(msg: any): void {
  scheduleSessionsRefresh('assistant_run_end');
  const runSp = msg.sessionPath;
  if (runSp) {
    requestContextUsage(runSp);
    // 插话切分（runSplit）只是 Run 语义边界，会话仍在流式：
    // 「回复结束后自动压缩」必须等真正的终态，否则会被服务端以 streaming 拒绝且丢单。
    if (!msg.runSplit) maybeRunPendingAutoCompact(runSp);
  } else {
    console.warn('[ws] assistant_run_end missing sessionPath, skipping context_usage request');
  }
}

/**
 * 50% 询问弹窗里用户选了「回复结束后压缩」：run 结束后自动补发 compact。
 * 服务端在 streaming 中会拒绝压缩（session_streaming），所以等到这一刻才发。
 */
function maybeRunPendingAutoCompact(sessionPath: string): void {
  const state = useStore.getState();
  if (!state.pendingAutoCompactSessions?.includes(sessionPath)) return;
  state.removePendingAutoCompact?.(sessionPath);
  const locatorEntry = state.sessionLocatorsById
    ? Object.entries(state.sessionLocatorsById as Record<string, { path?: string }>)
      .find(([, loc]) => loc?.path === sessionPath)
    : undefined;
  const sessionId = nonEmptyString(locatorEntry?.[0]);
  const ws = getWebSocket();
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({
    type: 'compact',
    ...(sessionId ? { sessionId } : {}),
    sessionPath,
  }));
}

function compactionIdentity(msg: any): { key: string | null; sessionId: string | null; sessionPath: string | null } {
  const { sessionId, sessionPath } = sessionIdentityFromMessage(msg);
  return { key: sessionId || sessionPath, sessionId, sessionPath };
}

function setCompactionBusy(msg: any, busy: boolean): void {
  const { key, sessionId, sessionPath } = compactionIdentity(msg);
  if (!key) return;
  useStore.setState((state: any) => {
    const compactingSessions = state.compactingSessions || [];
    const wasBusy = compactingSessions.some((item: string) => (
      item === key || item === sessionId || item === sessionPath
    ));
    const withoutIdentity = compactingSessions.filter((item: string) => (
      item !== key && item !== sessionId && item !== sessionPath
    ));
    const compactionModeBySession = { ...(state.compactionModeBySession || {}) };
    const priorMode = wasBusy
      ? compactionModeBySession[key]
        || (sessionId ? compactionModeBySession[sessionId] : null)
        || (sessionPath ? compactionModeBySession[sessionPath] : null)
      : null;
    const incomingMode = typeof msg.mode === 'string' && msg.mode.trim()
      ? msg.mode.trim()
      : null;
    delete compactionModeBySession[key];
    if (sessionId) delete compactionModeBySession[sessionId];
    if (sessionPath) delete compactionModeBySession[sessionPath];
    if (busy && (incomingMode || priorMode)) {
      compactionModeBySession[key] = incomingMode || priorMode;
    }
    return {
      compactingSessions: busy ? [...withoutIdentity, key] : withoutIdentity,
      compactionModeBySession,
    };
  });
}

function updateCompactionContext(msg: any): void {
  const { key, sessionId, sessionPath } = compactionIdentity(msg);
  if (!key) return;
  useStore.setState((state: any) => {
    const existing = state.contextBySession?.[key]
      || (sessionPath ? sessionScopedValue(state, state.contextBySession, sessionPath) : null);
    const value = {
      tokens: msg.tokens ?? null,
      window: msg.contextWindow ?? existing?.window ?? null,
      percent: msg.percent ?? null,
      // 与 context_usage 同一语义:字段缺失保留旧值,显式 null 清除(compaction 后
      // 服务端对账不出明细时主动置空,避免压缩前的旧明细残留在详情视图)。
      breakdown: msg.breakdown !== undefined ? msg.breakdown : existing?.breakdown,
    };
    const contextBySession = { ...(state.contextBySession || {}), [key]: value };
    if (sessionId && sessionPath && sessionId !== sessionPath) delete contextBySession[sessionPath];
    const focused = (sessionId && state.currentSessionId === sessionId)
      || (!sessionId && sessionPath && state.currentSessionPath === sessionPath);
    return {
      contextBySession,
      ...(focused ? {
        contextTokens: value.tokens,
        contextWindow: value.window,
        contextPercent: value.percent,
      } : {}),
    };
  });
}

function applyCompactionMessage(msg: any): void {
  if (msg.type === 'compaction_accepted' || msg.type === 'compaction_start') {
    setCompactionBusy(msg, true);
    return;
  }
  if (msg.type === 'compaction_end') {
    setCompactionBusy(msg, false);
    updateCompactionContext(msg);
    const { sessionPath: endSp } = compactionIdentity(msg);
    if (endSp) {
      const st = useStore.getState();
      st.clearCompactionAsk?.(endSp);
      st.removePendingAutoCompact?.(endSp);
    }
    return;
  }
  if (msg.type !== 'compaction_result') return;

  setCompactionBusy(msg, false);
  if (msg.status === 'noop' || msg.status === 'failed') {
    const message = nonEmptyString(msg.message)
      || (msg.status === 'noop' ? 'Nothing to compact' : 'Compaction failed');
    useStore.getState().addToast(message, msg.status === 'noop' ? 'info' : 'error', 6000, {
      dedupeKey: `compaction-result:${msg.sessionId || msg.sessionPath || 'unknown'}:${msg.status}`,
    });
  }
}

export function applyStreamingStatus(
  isStreaming: boolean,
  sessionPath: string | null,
  identity: { streamId?: string | null; turnId?: string | null } = {},
  options: { force?: boolean } = {},
): boolean {
  // 元数据层：把 isStreaming 视为 sessionPath 维度的权威信号，统一写回 streamingSessions。
  // 这一层不分焦点，任何来源（普通 status、stream_resume 恢复）都必须到达这里，
  // 否则重连后服务端说「已结束」前端却留着旧的 streaming 标记，UI 会卡在"思考中"。
  const wasStreaming = !!sessionPath
    && sessionScopedListIncludes(useStore.getState(), useStore.getState().streamingSessions, sessionPath);
  if (sessionPath) {
    if (isStreaming) {
      useStore.getState().addStreamingSession(sessionPath, identity);
      useStore.getState().clearInlineError(sessionPath);
      // 新一轮输出开始 = 旧失败已进入新回合，列表红点随之撤销。
      useStore.getState().clearSessionFailed?.(sessionPath);
    } else {
      const applied = options.force
        ? useStore.getState().forceRemoveStreamingSession(sessionPath)
        : useStore.getState().removeStreamingSession(sessionPath, identity);
      if (!applied) return false;
    }
  }

  if (!isStreaming && wasStreaming) {
    requestInputFocusForCurrentSession(sessionPath);
    const focused = useStore.getState().currentSessionPath;
    if (sessionPath && sessionPath !== focused) {
      useStore.getState().markSessionOutputUnread?.(sessionPath);
    }
  }

  // 渲染层：只有焦点 session 才影响 UI 占位 / sessions 列表。
  const focused = useStore.getState().currentSessionPath;
  if (sessionPath && sessionPath !== focused) return false;
  if (isStreaming) {
    ensureCurrentSessionVisible();
  } else if (hasOptimisticCurrentSession()) {
    scheduleSessionsRefresh('optimistic_session_settled');
  }
  return true;
}

function attachmentsEqual(a: any, b: any): boolean {
  const left = Array.isArray(a) ? a : [];
  const right = Array.isArray(b) ? b : [];
  if (left.length !== right.length) return false;
  for (let i = 0; i < left.length; i += 1) {
    const la = left[i] || {};
    const rb = right[i] || {};
    if ((la.path || '') !== (rb.path || '')) return false;
    if ((la.name || '') !== (rb.name || '')) return false;
    if (!!la.isDir !== !!rb.isDir) return false;
    if ((la.mimeType || '') !== (rb.mimeType || '')) return false;
    if ((la.base64Data || '') !== (rb.base64Data || '')) return false;
    if ((la.status || '') !== (rb.status || '')) return false;
    if ((la.missingAt ?? null) !== (rb.missingAt ?? null)) return false;
    if (!!la.visionAuxiliary !== !!rb.visionAuxiliary) return false;
  }
  return true;
}

function sameJsonish(a: any, b: any): boolean {
  return JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
}

function normalizeMessageTimestamp(value: unknown): number {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) return parsed;
  }
  return Date.now();
}

function replayUserMessageAlreadyHydrated(sessionPath: string, message: any): boolean {
  const state = useStore.getState();
  const session = sessionScopedValue(state, state.chatSessions, sessionPath);
  const last = session?.items?.[session.items.length - 1];
  if (!last || last.type !== 'message' || last.data?.role !== 'user') return false;
  const text = typeof message?.text === 'string' ? message.text : '';
  return last.data.text === text &&
    (last.data.quotedText || '') === (message?.quotedText || '') &&
    attachmentsEqual(last.data.attachments, message?.attachments) &&
    sameJsonish(last.data.deskContext, message?.deskContext);
}

function applyVoiceTranscriptionUpdate(msg: any): void {
  const sessionPath = typeof msg.sessionPath === 'string' ? msg.sessionPath : '';
  const fileId = typeof msg.fileId === 'string' ? msg.fileId : '';
  const transcription = msg.transcription && typeof msg.transcription === 'object' ? msg.transcription : null;
  if (!sessionPath || !fileId || !transcription) return;

  let changed = false;
  useStore.setState((s: any) => {
    const session = sessionScopedValue<any>(s, s.chatSessions, sessionPath);
    if (!session) return {};
    const items = session.items.map((item: any) => {
      if (item?.type !== 'message' || !Array.isArray(item.data?.attachments)) return item;
      let itemChanged = false;
      const attachments = item.data.attachments.map((attachment: any) => {
        if (attachment?.fileId !== fileId) return attachment;
        itemChanged = true;
        return { ...attachment, transcription };
      });
      if (!itemChanged) return item;
      changed = true;
      return { ...item, data: { ...item.data, attachments } };
    });
    if (!changed) return {};
    const sessionKey = sessionScopedKey(s, sessionPath) || sessionPath;
    const chatSessions = {
      ...s.chatSessions,
      [sessionKey]: { ...session, items },
    };
    if (sessionKey !== sessionPath) delete chatSessions[sessionPath];
    return {
      chatSessions,
    };
  });
  if (changed) bumpMessageLiveVersion(sessionPath);
}

function applyInputSessionConfirmationBlock(msg: any): void {
  if (msg.type !== 'content_block') return;
  const block = msg.block;
  if (block?.type !== 'session_confirmation' || block.surface !== 'input') return;
  const sessionPath = typeof msg.sessionPath === 'string' ? msg.sessionPath.trim() : '';
  if (!sessionPath) {
    console.warn('[ws] input session_confirmation missing sessionPath, skipping pending cache');
    return;
  }
  useStore.getState().setPendingSessionConfirmation?.(
    sessionPath,
    block.status === 'pending' ? block : null,
  );
}


// ── 知识过程 → 合成工具卡（2026-08-31 四轮）──
// 把 knowledge_trace / knowledge_rollup_progress / knowledge_supplement_search
// 翻译成 tool_start / tool_end 喂给既有工具卡管线：每个动作一张卡，从上往下
// 长在助手消息流里（与编程 Agent 调工具/执行命令同一形态；tool_start 在无
// 消息时会自动创建助手消息，后续 assistant_run_start/答案正文复用同一条）。
// 卡片是纯前端合成（不出现在会话流协议里）；toolCallId 以 kt- 前缀幂等防重。
const knowledgeReadCardBySession = new Map<string, string>();
/** 「正在生成回答」卡在途的 session（无该卡的会话绝不喂合成 tool_end——空卡
 * 的 tool_end 也会经 ensureMessage 凭空创建第二条助手消息）。 */
const knowledgeAnswerCardSessions = new Set<string>();

function feedKnowledgeToolCard(sp: string, event: Record<string, unknown> & { type: string }): void {
  streamBufferManager.handleLocal({ ...event, sessionPath: sp });
}

function feedKnowledgeThinkCard(sp: string, id: string, phase: string): void {
  feedKnowledgeToolCard(sp, phase === 'start'
    ? { type: 'tool_start', id, name: 'knowledge_think' }
    : { type: 'tool_end', id, success: phase !== 'failed' });
}

function translatorT(): (key: string, vars?: Record<string, string>) => string {
  const t = typeof window !== 'undefined' ? window.t : null;
  return t ?? ((key: string) => key);
}

function feedKnowledgeSearchCard(sp: string, id: string, phase: string, query?: string, hits?: number): void {
  const t = translatorT();
  feedKnowledgeToolCard(sp, phase === 'start'
    ? { type: 'tool_start', id, name: 'knowledge_search', args: { query: query ?? '' } }
    : {
      type: 'tool_end',
      id,
      success: phase !== 'failed',
      resultNote: phase === 'failed'
        ? t('chat.knowledgeTraceFailed')
        : t('chat.knowledgeTraceResults', { n: String(hits ?? 0) }),
    });
}

function feedKnowledgeReadCard(sp: string, current: number, total: number): void {
  const previous = knowledgeReadCardBySession.get(sp);
  if (previous) {
    feedKnowledgeToolCard(sp, { type: 'tool_end', id: previous, success: true });
  }
  const id = `kt-read-${current}`;
  feedKnowledgeToolCard(sp, {
    type: 'tool_start',
    id,
    name: 'knowledge_read_part',
    args: { current: String(current), total: String(total) },
  });
  knowledgeReadCardBySession.set(sp, id);
}

function settleKnowledgeReadCard(sp: string): void {
  const open = knowledgeReadCardBySession.get(sp);
  if (open) {
    feedKnowledgeToolCard(sp, { type: 'tool_end', id: open, success: true });
    knowledgeReadCardBySession.delete(sp);
  }
}

// ── 消息分发（大 switch） ──
// 返回值：水位管辖帧（isStreamScopedMessage / REACT_CHAT_EVENTS / status）被接纳
// 门禁拒绝时返回 false；其余路径返回 true（已消费/已分发）或不返回（非水位帧）。
// stream-resume 的重放层据此区分“帧已消费”与“帧已调用但被拒”。
export function handleServerMessage(msg: any, originConnectionKey = composerOriginConnectionKey()): boolean | void {
  if (originConnectionKey !== composerOriginConnectionKey()) return;
  // 高频 terminal_output 只能做只读身份校验；即使 locator 没变化，也不能调用
  // Zustand setState，否则卡片折叠时仍会让整棵状态树持续更新。
  if (!rememberSessionLocatorFromMessage(msg, { write: msg?.type !== 'terminal_output' })) return;
  const state = useStore.getState();

  const rebuildingFor = isStreamResumeRebuilding();

  if (rebuildingFor && msg.type === 'status' && state.currentSessionPath === rebuildingFor) {
    return;
  }

  if (
    rebuildingFor &&
    isStreamScopedMessage(msg) &&
    msg.sessionPath === rebuildingFor &&
    !msg.__fromReplay &&
    msg.type !== 'stream_resume'
  ) {
    return;
  }

  if (msg.type !== 'stream_resume' && (isStreamScopedMessage(msg) || REACT_CHAT_EVENTS.has(msg.type) || msg.type === 'status')) {
    if (!updateSessionStreamMeta(msg)) return false;
  }

  // 「知识库检索中」胶囊与「等待助手」pending 都是纯瞬态信号：该 session 的
  // 任何后续事件（status / 聊天流事件 / error…）到达都代表前一阶段已结束，
  // 保守清除（各 end 内部对未命中 session 都是零成本 no-op）。
  // knowledge_retrieval_started 自身不清 pending（发送 → 检索是同一段等待），
  // 也不被自己清除；knowledge_rollup_progress / knowledge_supplement_search
  // 是检索期内的滚动注入分段进度（自身不清检索态），同样排除。
  // session_user_message 是自己刚发出消息的接收回执，不代表助手开始响应：
  // 「等待助手」pending 必须保留到真正的助手活动，否则回执 → run_start 的
  // 空窗会让排队续发抢跑（F2）。回执对知识检索胶囊的清除语义保持不变。
  if (msg?.type !== 'knowledge_retrieval_started'
    && msg?.type !== 'knowledge_trace'
    && msg?.type !== 'knowledge_rollup_progress'
    && msg?.type !== 'knowledge_supplement_search') {
    const { sessionPath: retrievalDonePath } = sessionIdentityFromMessage(msg);
    // 与 markSessionOutputUnread? 同策略：部分测试 store / 旧 slice 组合缺 action 时不炸。
    if (retrievalDonePath) {
      useStore.getState().endKnowledgeRetrieval?.(retrievalDonePath);
      if (msg?.type !== 'session_user_message') {
        useStore.getState().endTurnPending?.(retrievalDonePath);
      }
      useStore.getState().endKnowledgeRollup?.(retrievalDonePath);
      useStore.getState().endKnowledgeSupplement?.(retrievalDonePath);
    }
  }

  if (
    msg.type === 'compaction_accepted'
    || msg.type === 'compaction_result'
    || msg.type === 'compaction_start'
    || msg.type === 'compaction_end'
  ) {
    applyCompactionMessage(msg);
    if (msg.type === 'compaction_accepted' || msg.type === 'compaction_result') return;
  }

  applyInputSessionConfirmationBlock(msg);

  // 知识过程卡的收口（2026-08-31 四轮）：答案正文开始流式输出时收尾阅读卡与
  // 「正在生成回答」卡（正文与卡片同在一条助手消息里）；run 结束兜底（中止/
  // 空回包）。卡片由流缓冲随消息渲染，无需额外清除。
  if (msg.type === 'text_delta' || msg.type === 'assistant_run_end') {
    const { sessionPath: traceDonePath } = sessionIdentityFromMessage(msg);
    if (traceDonePath && knowledgeAnswerCardSessions.has(traceDonePath)) {
      settleKnowledgeReadCard(traceDonePath);
      feedKnowledgeToolCard(traceDonePath, { type: 'tool_end', id: 'kt-answer', success: true });
      knowledgeAnswerCardSessions.delete(traceDonePath);
    } else if (traceDonePath) {
      // 无回答卡的会话仍要收尾可能的阅读卡（map 空时为 no-op）。
      settleKnowledgeReadCard(traceDonePath);
    }
  }

  if (['assistant_run_start', 'assistant_run_end', 'session_user_message', 'status'].includes(msg.type)) {
    noteComposerRunEvent(msg, originConnectionKey);
  }

  // 活跃 block 事件路由：非当前 session 的聊天事件也要写入正常聊天缓存。
  // stream-key-dispatcher 只负责卡片/预览订阅，不能吞掉主 transcript 的后台流。
  if (REACT_CHAT_EVENTS.has(msg.type) && msg.sessionPath && msg.sessionPath !== state.currentSessionPath) {
    if (isKnownChatSession(msg.sessionPath, state)) {
      streamBufferManager.handle(msg);
    }
    if (msg.type === 'assistant_run_end') {
      applyRunEndSideEffects(msg);
    }
    dispatchStreamKey(msg.sessionPath, msg);
    applyTodoToolEnd(msg);
    applyToolEndSessionFile(msg);
    applyContentBlockSessionFile(msg);
    return true;
  }

  // ── React 聊天渲染路径：聊天相关事件走 StreamBufferManager ──
  if (REACT_CHAT_EVENTS.has(msg.type)) {
    streamBufferManager.handle(msg);
    // assistant_run_end 后仍需执行部分通用逻辑（loadSessions、context_usage）
    if (msg.type === 'assistant_run_end') {
      applyRunEndSideEffects(msg);
    }
    // tool_end 后更新 todo（兼容新旧工具名 + 新旧格式）
    applyTodoToolEnd(msg);
    if (msg.type === 'tool_end') {
      applyToolEndSessionFile(msg);
    }
    applyContentBlockSessionFile(msg);
    // COMPAT(create_artifact, remove no earlier than v0.133):
    // 旧 artifact block 进入当前 Preview 面板。
    if (msg.type === 'content_block' && msg.block?.type === 'artifact' && state.currentTab === 'chat') {
      handleLegacyArtifactBlock({ ...msg.block, sessionPath: msg.sessionPath });
    }
    return true;
  }

  // 非聊天渲染事件走传统 switch
  switch (msg.type) {
    case 'resource.changed': {
      markDeskTreeDirtyForResourceChange(msg);
      void refreshOpenPreviewDocumentsForResourceChange(
        msg,
        PREVIEW_DOCUMENT_CHANGE_REFRESH_OPTIONS,
      );
      break;
    }
    case 'resource.deleted':
    case 'resource.renamed': {
      markDeskTreeDirtyForResourceChange(msg);
      void refreshOpenPreviewDocumentsForResourceChange(
        msg,
        PREVIEW_DOCUMENT_CHANGE_REFRESH_OPTIONS,
      );
      break;
    }
    case 'session_branch_reset': {
      const sp = msg.sessionPath;
      const targetIds = [...new Set([msg.clientMessageId, msg.messageId, msg.projectionMessageId]
        .filter((id): id is string => typeof id === 'string' && !!id))];
      if (!sp || targetIds.length === 0) { console.warn('[ws] session_branch_reset missing sessionPath or message id'); break; }
      let truncated = false;
      for (const targetId of targetIds) {
        if (useStore.getState().truncateSessionFromMessage(sp, targetId)) {
          truncated = true;
          break;
        }
      }
      bumpMessageLiveVersion(sp);
      if (!truncated) {
        console.warn('[ws] session_branch_reset target message not found:', sp, targetIds);
      }
      if (msg.todoPanel && Array.isArray(msg.todoPanel.todos) && msg.todoPanel.todos.length > 0) {
        // 服务端分支重置携带的权威面板快照（含版本与收尾标志）
        useStore.getState().setSessionTodoPanel(sp, {
          todos: msg.todoPanel.todos,
          version: typeof msg.todoPanel.version === 'string' ? msg.todoPanel.version : null,
          finished: msg.todoPanel.finished === true,
          allCompleted: msg.todoPanel.allCompleted === true,
          dismissed: false,
          updateFailed: false,
        });
        useStore.getState().bumpTodosLiveVersion(sp);
      } else if (Array.isArray(msg.todos)) {
        // 旧负载：服务端已完成生命周期投影，非空数组即活动清单
        if (msg.todos.length > 0) {
          useStore.getState().setSessionTodoPanel(sp, {
            todos: msg.todos,
            version: null,
            finished: false,
            allCompleted: false,
            dismissed: false,
            updateFailed: false,
          });
        } else {
          useStore.getState().setSessionTodoPanel(sp, null);
        }
        useStore.getState().bumpTodosLiveVersion(sp);
      }
      useStore.getState().applyBranchResetSessionFiles(
        sp,
        Array.isArray(msg.sessionFiles) ? msg.sessionFiles : null,
      );
      // 「回退时撤销文件改动」逐文件报告：HTTP 响应之外的广播通道，
      // 其它窗口/入口触发的回退也能看到同一份报告。
      if (msg.fileRollbackReport && typeof msg.fileRollbackReport === 'object') {
        useStore.getState().setFileRollbackReport?.(sp, msg.fileRollbackReport);
      }
      break;
    }

    case 'stream_resume':
      replayStreamResume(msg);
      break;

    case 'session_title':
      if (msg.title) {
        useStore.setState({
          sessions: state.sessions.map((s: any) =>
            s.path === msg.path ? { ...s, title: msg.title } : s,
          ),
        });
      }
      break;

    case 'session_created':
      upsertCreatedSession(msg);
      scheduleSessionsRefresh('session_created');
      break;

    case 'browser_status':
    case 'browser_update':
      applyBrowserStatus(msg);
      break;

    case 'todo_update': {
      const sp = msg.sessionPath;
      if (!sp) { console.warn('[ws] event missing sessionPath:', msg.type); break; }
      // 服务端权威收尾/收纳结果：removed 或 dismissed → 当前展示隐藏（历史保留）；
      // 否则应用完整面板快照（含版本与收尾标志）。
      if (msg.removed === true || msg.dismissed === true) {
        useStore.getState().setSessionTodoPanel(sp, null);
      } else if (Array.isArray(msg.todos) && msg.todos.length > 0) {
        useStore.getState().setSessionTodoPanel(sp, {
          todos: msg.todos,
          version: typeof msg.version === 'string' ? msg.version : null,
          finished: msg.finished === true,
          allCompleted: msg.allCompleted === true,
          dismissed: false,
          updateFailed: false,
        });
      } else {
        // 空清单（含旧版 {todos: []} 负载）= 当前无应显示的清单
        useStore.getState().setSessionTodoPanel(sp, null);
      }
      useStore.getState().bumpTodosLiveVersion(sp);
      break;
    }

    case 'browser_bg_status': {
      const bgSp = msg.sessionPath;
      if (!bgSp) { console.warn('[ws] event missing sessionPath:', msg.type); break; }
      const prev = browserStateForPath(useStore.getState(), bgSp);
      const bgRunning = !!msg.running;
      setBrowserStateForPath(bgSp, {
        ...prev,
        running: bgRunning,
        lastActiveAt: bgRunning ? (prev?.lastActiveAt ?? Date.now()) : (prev?.lastActiveAt ?? null),
      });
      break;
    }

    case 'computer_overlay': {
      const sp = msg.sessionPath;
      if (!sp) { console.warn('[ws] event missing sessionPath:', msg.type); break; }
      if (msg.phase === 'clear') {
        useStore.getState().clearComputerOverlayForSession(sp);
      } else {
        useStore.getState().setComputerOverlayForSession(sp, {
          phase: msg.phase || 'running',
          action: msg.action || 'computer',
          agentId: msg.agentId ?? null,
          leaseId: msg.leaseId ?? null,
          snapshotId: msg.snapshotId ?? null,
          target: msg.target ?? null,
          inputMode: msg.inputMode === 'foreground-input' ? 'foreground-input' : 'background',
          visualSurface: msg.visualSurface === 'provider' ? 'provider' : 'renderer',
          requiresForeground: msg.requiresForeground === true,
          interruptKey: msg.interruptKey ?? null,
          errorCode: msg.errorCode ?? null,
          ts: msg.ts || Date.now(),
        });
      }
      break;
    }

    case 'block_update': {
      const { taskId, patch, sessionPath: sp } = msg;
      if (!taskId || !patch) break;
      if (!sp) { console.warn('[ws] event missing sessionPath:', msg.type); break; }
      useStore.getState().patchBlockByTaskId(sp, taskId, patch);
      break;
    }

    case 'activity_update':
      if (msg.activity) {
        useStore.setState((current: any) => {
          const incoming = msg.activity;
          const existing = current.activities.find((activity: any) => activity.id === incoming.id);
          const merged = existing ? { ...existing, ...incoming } : incoming;
          return {
            activities: [
              merged,
              ...current.activities.filter((activity: any) => activity.id !== incoming.id),
            ].slice(0, 500),
          };
        });
      }
      break;

    case 'agent_activity':
      // 统一 Agent Activity 真相源（ActivityHub 广播）：subagent / workflow / 巡检
      if (msg.entry?.id) {
        useStore.getState().upsertAgentActivity(msg.entry);
      }
      break;

    case 'terminal_snapshot':
      if (msg.sessionPath && Array.isArray(msg.terminals)) {
        useStore.getState().replaceTerminalSnapshot({
          sessionId: msg.sessionId ?? null,
          sessionPath: msg.sessionPath,
          terminals: msg.terminals,
        });
      }
      break;

    case 'terminal_state':
      if (msg.terminal?.terminalId && msg.sessionPath) {
        useStore.getState().upsertTerminal({
          ...msg.terminal,
          sessionId: msg.sessionId ?? msg.terminal.sessionId ?? null,
          sessionPath: msg.sessionPath,
        });
      }
      break;

    case 'terminal_tail':
      terminalOutputStream.handleTail(msg);
      break;

    case 'terminal_output':
      terminalOutputStream.handleChunks(msg);
      break;

    case 'notification':
      if (window.hana?.showNotification) {
        // agentId 标识触发通知的助手，主进程据此读取该 agent 头像作为通知 icon。
        // 缺失时透传 null，主进程退回无 icon，禁止从当前焦点 agent 兜底。
        window.hana.showNotification(msg.title, msg.body, msg.agentId ?? null, {
          desktopFocusPolicy: resolveNotificationDesktopFocusPolicy(msg),
        });
      }
      break;

    case 'bridge_status':
      useStore.getState().triggerBridgeReload();
      break;

    case 'env_deps_status': {
      // 启动自检发现「项目需要但没装」的依赖：toast 提醒 + 一键打开环境依赖页。
      const missing: string[] = Array.isArray(msg.missing) ? msg.missing.filter((x: any) => typeof x === 'string') : [];
      if (missing.length > 0) {
        const names = missing.join('、');
        useStore.getState().addToast(
          window.t?.('envDeps.startupMissing', { names }) ?? `缺少项目需要的环境依赖：${names}`,
          'warning',
          8000,
          {
            dedupeKey: 'env-deps-startup',
            action: {
              label: window.t?.('envDeps.openSettings') ?? '查看',
              onClick: () => openSettingsModal('envdeps'),
            },
          },
        );
      }
      break;
    }

    case 'app_event':
      if (msg.event?.type) {
        handleAppEvent(msg.event.type, msg.event.payload || {}, { source: msg.event.source || 'server' });
      }
      break;

    case 'bridge_message':
      if (msg.message) {
        useStore.getState().addBridgeMessage(msg.message);
      }
      break;

    case 'agent_review_status': {
      const sp = nonEmptyString(msg.sessionPath);
      const requestId = nonEmptyString(msg.requestId);
      if (!sp || !requestId) break;
      const session = sessionScopedValue(useStore.getState(), useStore.getState().chatSessions, sp);
      const item = session?.items.find((candidate: any) => (
        candidate.type === 'message' && candidate.data.role === 'user' && candidate.data.id === requestId
      ));
      if (!item || item.type !== 'message') break;
      useStore.getState().appendOptimisticUserMessage(sp, {
        ...item.data,
        agentReview: {
          requestId,
          status: msg.status,
          reviewedSessionId: msg.reviewedSessionId ?? null,
          reviewerSessionId: msg.reviewerSessionId ?? null,
          reviewerAgentId: msg.reviewerAgentId,
          reviewerAgentName: msg.reviewerAgentName,
          text: msg.result ?? item.data.agentReview?.text ?? null,
          error: msg.error ?? null,
        },
      });
      break;
    }

    case 'session_user_message': {
      const sp = msg.sessionPath;
      if (!sp || !msg.message) break;
      const current = useStore.getState();
      if (!sessionScopedValue(current, current.chatSessions, sp)) {
        useStore.getState().initSession(sp, [], false);
      }
      if (msg.__fromReplay === true && replayUserMessageAlreadyHydrated(sp, { ...msg.message, text: extractLeadingSkillNotes(typeof msg.message.text === 'string' ? msg.message.text : '').text })) {
        break;
      }
      const rawText = typeof msg.message.text === 'string' ? msg.message.text : '';
      // 服务端把手动技能调用落盘成 [Use skill: x] 前缀；回放事件可能只有这段
      // 前缀而没有结构化 skills。这里与 history-builder 同步剥前缀、回填胶囊，
      // 水合守卫的比较文本也用剥离后的值，两边形状一致才不会重复插入。
      const notes = extractLeadingSkillNotes(rawText);
      const echoedSkills = Array.isArray(msg.message.skills)
        ? msg.message.skills.filter((name: unknown): name is string => typeof name === 'string' && !!name.trim())
        : [];
      const text = notes.text;
      const textHtml = text ? renderMarkdown(text) : undefined;
      const skills = echoedSkills.length > 0
        ? echoedSkills
        : (notes.skills.length > 0 ? notes.skills : undefined);
      const clientMessageId = typeof msg.clientMessageId === 'string' && msg.clientMessageId
        ? msg.clientMessageId
        : typeof msg.message.clientMessageId === 'string' && msg.message.clientMessageId
          ? msg.message.clientMessageId
          : null;
      // 发送回执关联（含重连后恢复/历史回放）：coordinator 据此把 awaiting_ack /
      // delivery_unknown 记录转为 accepted；不是磁盘 fsync 回执，不冒充持久化。
      const acknowledged = noteComposerServerAck(clientMessageId, {
        originConnectionKey, sessionId: msg.sessionId, sessionPath: sp,
        snapshotVersion: msg.snapshotVersion ?? msg.message.snapshotVersion,
        sourceEntryId: msg.message.sourceEntryId || msg.message.id,
      });
      // 预提交展示事件仍可能早于 canonical user append；它不能清除本地未知状态。
      if (clientMessageId && findSendRecordByClientMessageId(clientMessageId) && !acknowledged) break;
      const serverMessageId = typeof msg.message.id === 'string' && msg.message.id
        ? msg.message.id
        : typeof msg.message.sourceEntryId === 'string' && msg.message.sourceEntryId
          ? msg.message.sourceEntryId
          : undefined;
      const data = {
        id: clientMessageId || serverMessageId || `user-${Date.now()}`,
        sourceEntryId: serverMessageId,
        role: 'user' as const,
        text,
        textHtml,
        timestamp: normalizeMessageTimestamp(msg.message.timestamp),
        attachments: msg.message.attachments,
        quotedText: msg.message.quotedText,
        skills,
        sessionRefs: msg.message.sessionRefs ?? undefined,
        agentMentions: msg.message.agentMentions ?? undefined,
        knowledgeRefs: msg.message.knowledgeRefs ?? undefined,
        knowledgeRetrieval: msg.message.knowledgeRetrieval ?? undefined,
        agentReview: msg.message.agentReview ?? undefined,
        agentReviewRequest: msg.message.agentReviewRequest ?? undefined,
        deskContext: msg.message.deskContext ?? undefined,
        origin: msg.message.origin ?? undefined,
      };
      if (clientMessageId && useStore.getState().confirmOptimisticUserMessage(sp, clientMessageId, data)) {
        bumpMessageLiveVersion(sp);
        if (sp === useStore.getState().currentSessionPath) {
          useStore.setState({ welcomeVisible: false });
        }
        break;
      }
      useStore.getState().appendItem(sp, { type: 'message', data });
      bumpMessageLiveVersion(sp);
      if (sp === useStore.getState().currentSessionPath) {
        useStore.setState({ welcomeVisible: false });
      }
      break;
    }

    case 'loop_status': {
      // 循环状态机变更（start/stop/pause/resume/complete/轮次刷新）。按 sessionId 写 store，
      // 驱动会话列表徽章与 interlude 控制按钮态。stopped/completed 经 setLoopStatus 自动清除。
      if (msg.sessionId) {
        const runtimeError = readLoopRuntimeError(msg.runtimeError);
        useStore.getState().setLoopStatus(msg.sessionId, {
          status: msg.status,
          turnCount: msg.turnCount ?? 0,
          maxTurns: msg.maxTurns ?? null,
          pausedReason: msg.pausedReason ?? null,
          prompt: msg.prompt ?? null,
          ...(runtimeError ? { runtimeError } : {}),
        });
        warnLoopRuntimeError(msg.sessionId, runtimeError);
      }
      break;
    }

    case 'voice_transcription_update': {
      applyVoiceTranscriptionUpdate(msg);
      break;
    }

    case 'bridge_rc_attached': {
      const sp = msg.sessionPath;
      if (sp && msg.sessionKey) {
        useStore.setState((s) => ({
          sessions: s.sessions.map((session) => session.path === sp
            ? {
              ...session,
              rcAttachment: {
                sessionKey: msg.sessionKey,
                platform: msg.platform || 'bridge',
                title: msg.title || null,
              },
            }
            : session),
        }));
      }
      break;
    }

    case 'bridge_rc_detached': {
      const sp = msg.sessionPath;
      if (sp) {
        useStore.setState((s) => ({
          sessions: s.sessions.map((session) => session.path === sp
            ? { ...session, rcAttachment: null }
            : session),
        }));
      }
      break;
    }

    case 'session_metadata_updated': {
      const sp = msg.sessionPath;
      const sid = typeof msg.sessionId === 'string' && msg.sessionId.trim() ? msg.sessionId.trim() : null;
      const metadata = msg.metadata && typeof msg.metadata === 'object' ? msg.metadata : {};
      if (!sp) { console.warn('[ws] event missing sessionPath:', msg.type); break; }
      const hasPinnedAt = Object.prototype.hasOwnProperty.call(metadata, 'pinnedAt');
      const hasPinOrder = Object.prototype.hasOwnProperty.call(metadata, 'pinOrder');
      const hasProjectId = Object.prototype.hasOwnProperty.call(metadata, 'projectId');
      if (hasPinnedAt || hasPinOrder || hasProjectId) {
        useStore.setState((s) => ({
          sessions: s.sessions.map((session) => {
            if (session.path !== sp && (!sid || session.sessionId !== sid)) return session;
            return {
              ...session,
              ...(hasPinnedAt
                ? { pinnedAt: typeof metadata.pinnedAt === 'string' ? metadata.pinnedAt : null }
                : {}),
              ...(hasPinOrder
                ? { pinOrder: typeof metadata.pinOrder === 'number' ? metadata.pinOrder : null }
                : {}),
              ...(hasProjectId
                ? { projectId: typeof metadata.projectId === 'string' && metadata.projectId.trim() ? metadata.projectId.trim() : null }
                : {}),
            };
          }),
        }));
      }
      if (sp === useStore.getState().currentSessionPath && typeof metadata.thinkingLevel === 'string') {
        useStore.getState().setThinkingLevel(metadata.thinkingLevel);
      }
      break;
    }

    case 'plan_mode': {
      if (isFocusedSessionMessage(msg)) {
        const mode = msg.mode || (msg.enabled ? 'read_only' : 'operate');
        syncSessionPermissionMode(mode);
        window.dispatchEvent(new CustomEvent('hana-plan-mode', {
          detail: { enabled: !!msg.enabled, mode },
        }));
      }
      break;
    }

    case 'permission_mode': {
      if (isFocusedSessionMessage(msg)) {
        syncSessionPermissionMode(msg.mode);
        window.dispatchEvent(new CustomEvent('hana-plan-mode', {
          detail: { enabled: msg.mode === 'read_only', mode: msg.mode },
        }));
      }
      break;
    }

    case 'access_mode': {
      if (isFocusedSessionMessage(msg)) {
        const mode = msg.permissionMode || msg.mode;
        syncSessionPermissionMode(mode);
        window.dispatchEvent(new CustomEvent('hana-plan-mode', {
          detail: {
            enabled: msg.readOnly === true,
            mode,
          },
        }));
      }
      break;
    }

    case 'channel_new_message':
    case 'channel_created':
    case 'dm_new_message':
    case 'conversation_agent_activity':
      handleConversationEvent(msg);
      break;

    case 'compaction_auto': {
      // 80% 强制压缩完成通知：告知用户上下文已被自动压缩。
      const sp2 = msg.sessionPath;
      const state2 = useStore.getState();
      if (sp2) {
        state2.clearCompactionAsk?.(sp2);
        state2.removePendingAutoCompact?.(sp2);
      }
      state2.addToast?.(
        t('compaction.autoCompleted', { percent: String(msg.percentBefore ?? '') }),
        'success',
        6000,
        { dedupeKey: `compaction-auto:${sp2 || 'unknown'}:${msg.percentBefore ?? ''}` },
      );
      break;
    }

    case 'compaction_suggested': {
      // 50% 询问线：服务端不阻塞 run，只发一次询问；由弹窗决定是否压缩。
      const sp3 = msg.sessionPath;
      if (!sp3) { console.warn('[ws] event missing sessionPath:', msg.type); break; }
      useStore.getState().addCompactionAsk?.(sp3, {
        percent: Number(msg.percent) || 0,
        askPercent: Number(msg.askPercent) || 50,
        forcePercent: Number(msg.forcePercent) || 80,
      });
      break;
    }

    case 'context_usage': {
      const sp = msg.sessionPath;
      if (!sp) { console.warn('[ws] event missing sessionPath:', msg.type); break; }
      const existing = sessionScopedValue(useStore.getState(), useStore.getState().contextBySession, sp);
      const window = msg.contextWindow ?? existing?.window ?? null;
      if (msg.tokens != null || window != null || msg.percent != null) {
        // breakdown 为可选扩展字段:字段缺失(旧服务端)时保留旧值;显式 null
        // (如 compaction 后)表示服务端确认无明细,清掉旧值,不残留。
        const breakdown = msg.breakdown !== undefined ? msg.breakdown : existing?.breakdown;
        updateKeyed('contextBySession', sp,
          { tokens: msg.tokens ?? null, window, percent: msg.percent ?? null, breakdown },
          (_s, d) => ({ contextTokens: d.tokens, contextWindow: d.window, contextPercent: d.percent }),
        );
      }
      break;
    }

    case 'input_rejected': {
      // 服务端「接受前明确拒绝」的类型化回执（C01）：身份五元组由连接上下文 +
      // 服务端解析字段组成，coordinator 完成匹配检查、状态转换与 UI 投影更新。
      // 与 legacy error 独立——这里只结算发送记录，错误展示仍由 error 分支负责。
      const { sessionId: rejectedSessionId, sessionPath: rejectedSessionPath } = sessionIdentityFromMessage(msg);
      const clientMessageId = typeof msg.clientMessageId === 'string' && msg.clientMessageId.trim()
        ? msg.clientMessageId.trim()
        : null;
      const snapshotVersion = Number.isSafeInteger(msg.snapshotVersion) ? msg.snapshotVersion : null;
      if (!rejectedSessionId || !rejectedSessionPath || !clientMessageId || snapshotVersion == null) {
        console.warn('[ws] input_rejected missing identity fields; ignoring', msg);
        break;
      }
      if (msg.outcome !== 'not_accepted') {
        console.warn('[ws] input_rejected with unknown outcome; ignoring', { outcome: msg.outcome });
        break;
      }
      const receipt = {
        code: typeof msg.code === 'string' && msg.code.trim() ? msg.code.trim() : 'rejected_before_acceptance',
        retryable: msg.retryable === true,
      };
      noteComposerInputRejected({
        originConnectionKey,
        sessionId: rejectedSessionId,
        sessionPath: rejectedSessionPath,
        clientMessageId,
        snapshotVersion,
        clientAttemptId: typeof msg.clientAttemptId === 'string' && msg.clientAttemptId.trim() ? msg.clientAttemptId.trim() : null,
      }, receipt);
      break;
    }

    case 'error': {
      const { sessionPath: sp } = sessionIdentityFromMessage(msg);
      const presented = presentError(errorWithCode(
        String(msg.message ?? ''),
        typeof msg.code === 'string' ? msg.code : null,
      ));
      if (!sp) {
        // 身份类错误本身就说明没有会话可以挂靠，落不到 inline 位，只能弹 toast。
        // internal_contract 同理：服务端认定调用方没带身份，用户看不到就等于故障消失了。
        if (
          msg.code === 'session_identity_unresolved'
          || msg.code === 'session_identity_mismatch'
          || msg.code === 'internal_contract'
        ) {
          useStore.getState().addToast(presented.text, 'error', 6000, { errorCode: msg.code });
        } else {
          console.warn('[ws] event missing sessionPath:', msg.type);
        }
        break;
      }
      useStore.getState().setInlineError(sp, presented);
      // 错误条有 TTL 会自动消失，列表红点则常驻到用户切回查看为止。
      useStore.getState().markSessionFailed?.(sp);
      break;
    }

    case 'confirmation_resolved': {
      streamBufferManager.resolveSessionConfirmation(msg.confirmId, msg.action === 'confirmed' ? 'confirmed' : msg.action === 'timeout' ? 'timeout' : 'rejected');
      // 更新所有 session 中匹配 confirmId 的确认卡片状态。确认块可能不在最后一条消息，
      // 输入区也从消息块派生 pending 状态，所以这里按 session/message/block 三层显式定位。
      const nextStatusFor = (blockType: string): string => {
        if (msg.action === 'confirmed') return blockType === 'cron_confirm' || blockType === 'suggestion_card' ? 'approved' : 'confirmed';
        if (msg.action === 'timeout') return 'timeout';
        return 'rejected';
      };
      let changedPaths: string[] = [];
      useStore.setState((s: any) => {
        const chatSessions = s.chatSessions || {};
        let changed = false;
        const nextSessions: Record<string, any> = {};

        for (const [sp, session] of Object.entries(chatSessions) as Array<[string, any]>) {
          let sessionChanged = false;
          const items = (session.items || []).map((item: any) => {
            if (item.type !== 'message' || !item.data?.blocks) return item;
            let messageChanged = false;
            const blocks = item.data.blocks.map((b: any) => {
              const matchesType = b.type === 'settings_confirm'
                || b.type === 'cron_confirm'
                || b.type === 'suggestion_card'
                || b.type === 'session_confirmation';
              if (!matchesType || b.confirmId !== msg.confirmId) return b;
              messageChanged = true;
              return { ...b, status: nextStatusFor(b.type) };
            });
            if (!messageChanged) return item;
            sessionChanged = true;
            return { ...item, data: { ...item.data, blocks } };
          });
          if (!sessionChanged) {
            nextSessions[sp] = session;
            continue;
          }
          changed = true;
          changedPaths.push(sp);
          nextSessions[sp] = { ...session, items };
        }

        return changed ? { chatSessions: nextSessions } : {};
      });
      useStore.getState().resolvePendingSessionConfirmation?.(msg.confirmId);
      changedPaths = Array.from(new Set(changedPaths));
      for (const sp of changedPaths) bumpMessageLiveVersion(sp);
      break;
    }

    case 'apply_frontend_setting': {
      if (msg.key === 'theme') {
        window.applyTheme?.(msg.value);
        // 通知其他窗口（设置窗口等）同步主题
        window.platform?.settingsChanged?.('theme-changed', { theme: msg.value });
      }
      break;
    }

    case 'abort_result': {
      if (msg.status !== 'accepted' && msg.status !== 'already_stopped') {
        if (msg.status === 'rejected') console.warn('[ws] abort refused:', msg.reason);
        break;
      }
      const spAbort = msg.sessionPath || null;
      // 停止是用户显式终局：无论本次是否命中活跃 run（already_stopped 同样成立），
      // 都结算该会话账本（盖终局章 + 触发对账），不能只清忙闲状态。
      if (spAbort) noteComposerUserAbort(spAbort);
      if (msg.status !== 'already_stopped') break;
      const sp = msg.sessionPath || null;
      const sid = typeof msg.sessionId === 'string' && msg.sessionId.trim() ? msg.sessionId.trim() : null;
      const streamId = typeof msg.streamId === 'string' && msg.streamId.trim() ? msg.streamId.trim() : null;
      const applied = applyStreamingStatus(false, sp, { streamId }, { force: !streamId });
      if (sp && applied) streamBufferManager.finishRun(sp, sid);
      break;
    }

    case 'terminal_close_result':
    case 'subagent_stop_result': {
      handleBackgroundProcessControlResult(msg);
      break;
    }

    case 'status': {
      const sp = msg.sessionPath || null;
      // status 只回答「Session 是否忙」：streamingSessions 维护 + 焦点 UI 占位。
      // 它没有资格决定 Assistant Run 的生命周期——Run 只能由
      // assistant_run_start / assistant_run_end（见 REACT_CHAT_EVENTS → StreamBufferManager）开关，
      // 因此这里绝不允许调用 beginRun / finishRun / finalizeRun。
      applyStreamingStatus(msg.isStreaming, sp, {
        streamId: msg.streamId ?? null,
        turnId: msg.turnId ?? null,
      });
      // aborted:true 是服务器确认的「该会话运行已被终止」：用户终局信号，
      // 结算账本（盖终局章 + 触发对账）。普通 isStreaming:false 仍不解除未决输入。
      if (sp && msg.isStreaming === false && msg.aborted === true) {
        noteComposerUserAbort(sp);
      }
      break;
    }

    case 'knowledge_retrieval_started': {
      // 注入开始前广播（早于 status isStreaming:true），不进 stream_resume；
      // 检索结束由 handleServerMessage 顶部的保守清除负责（该 session 任意后续事件）。
      const sp = nonEmptyString(msg.sessionPath) || nonEmptyString(msg.path);
      if (!sp) { console.warn('[ws] knowledge_retrieval_started missing sessionPath, skipping'); break; }
      useStore.getState().beginKnowledgeRetrieval?.(sp);
      // 检索会挡住回执（落盘在检索之后）：延窗再等，不按 15s 默认窗口误判投递存疑。
      extendComposerAckWindow(sp);
      // 新一轮检索：收尾上一轮可能残留的阅读卡（跨轮 Map 泄漏防护）。
      settleKnowledgeReadCard(sp);
      break;
    }

    case 'knowledge_rollup_progress': {
      // 滚动注入中间轮进度（超预算证据分部分喂给主模型消化）：逐轮更新
      // 「正在阅读第 X/N 部分」胶囊；不进 stream_resume，结束由顶部保守清除。
      const sp = nonEmptyString(msg.sessionPath) || nonEmptyString(msg.path);
      if (!sp) { console.warn('[ws] knowledge_rollup_progress missing sessionPath, skipping'); break; }
      const current = Number(msg.current);
      const total = Number(msg.total);
      useStore.getState().updateKnowledgeRollup?.(sp, {
        current: Number.isSafeInteger(current) && current > 0 ? current : 1,
        total: Number.isSafeInteger(total) && total > 0 ? total : 1,
      });
      // 阅读卡：每部分一张卡（第 k 部分开始时收尾第 k-1 张）。
      feedKnowledgeReadCard(
        sp,
        Number.isSafeInteger(current) && current > 0 ? current : 1,
        Number.isSafeInteger(total) && total > 0 ? total : 1,
      );
      break;
    }

    case 'knowledge_supplement_search': {
      // 滚动循环内模型自主发起的补充检索（过程可见，不显中间内容）：展示查询行；
      // 不进 stream_resume，结束由顶部保守清除。
      const sp = nonEmptyString(msg.sessionPath) || nonEmptyString(msg.path);
      if (!sp) { console.warn('[ws] knowledge_supplement_search missing sessionPath, skipping'); break; }
      const queries = Array.isArray(msg.queries)
        ? msg.queries.filter((q: unknown): q is string => typeof q === 'string' && !!q.trim())
        : [];
      const round = Number(msg.round);
      useStore.getState().updateKnowledgeSupplement?.(sp, {
        queries,
        round: Number.isSafeInteger(round) && round > 0 ? round : 1,
      });
      // 补充检索决策卡（瞬时完成；随后每条真实检索经 knowledge_trace 各自成卡）。
      const t = translatorT();
      const supplementId = `kt-supplement-${Number.isSafeInteger(round) && round > 0 ? round : 1}`;
      feedKnowledgeToolCard(sp, { type: 'tool_start', id: supplementId, name: 'knowledge_supplement' });
      feedKnowledgeToolCard(sp, {
        type: 'tool_end',
        id: supplementId,
        success: true,
        resultNote: t('chat.knowledgeSupplementQueryCount', { count: String(queries.length) }),
      });
      break;
    }

    case 'knowledge_trace': {
      // 知识注入过程行（拆解/检索逐阶段）：按 id 原位更新过程行堆——start
      // 显示查询词/思考态，done 原位变成「N 个搜索结果」。不进 stream_resume，
      // 结束由顶部保守清除（真实轮消息到达整堆收起）。
      const sp = nonEmptyString(msg.sessionPath) || nonEmptyString(msg.path);
      if (!sp) { console.warn('[ws] knowledge_trace missing sessionPath, skipping'); break; }
      const id = nonEmptyString(msg.id);
      if (!id) { console.warn('[ws] knowledge_trace missing id, skipping'); break; }
      const phaseRaw = msg.phase === 'done' || msg.phase === 'failed' ? msg.phase : 'start';
      if (msg.detail === 'fast_local') {
        const t = translatorT();
        feedKnowledgeToolCard(sp, phaseRaw === 'start'
          ? { type: 'tool_start', id: `kt-${id}`, name: 'knowledge_local_search' }
          : { type: 'tool_end', id: `kt-${id}`, success: phaseRaw !== 'failed',
            resultNote: phaseRaw === 'failed' ? t('chat.knowledgeTraceFailed')
              : t('chat.knowledgeLocalEvidenceFound', {
                n: String(msg.hits ?? 0),
                ms: typeof msg.elapsedMs === 'number' && Number.isFinite(msg.elapsedMs)
                  ? String(Math.round(msg.elapsedMs)) : '—',
              }),
          });
      } else if (msg.kind === 'think') {
        feedKnowledgeThinkCard(sp, `kt-${id}`, phaseRaw);
      } else if (msg.detail === 'answer') {
        // 检索收口：阅读卡收尾 + 「正在生成回答」卡盖住主模型预填充等待。
        settleKnowledgeReadCard(sp);
        feedKnowledgeToolCard(sp, { type: 'tool_start', id: 'kt-answer', name: 'knowledge_answer' });
        knowledgeAnswerCardSessions.add(sp);
      } else {
        feedKnowledgeSearchCard(
          sp,
          `kt-${id}`,
          phaseRaw,
          typeof msg.query === 'string' ? msg.query : undefined,
          Number.isFinite(Number(msg.hits)) ? Number(msg.hits) : undefined,
        );
      }
      break;
    }

    case 'slash_result': {
      if (typeof window === 'undefined') break;
      if (!isFocusedSessionMessage(msg)) break;
      const text = typeof msg.text === 'string' ? msg.text.trim() : '';
      if (!text) break;
      window.dispatchEvent(new CustomEvent('hana-inline-notice', {
        detail: {
          text,
          type: msg.level === 'error' || msg.error ? 'error' : 'success',
        },
      }));
      break;
    }
  }
}

function applyToolEndSessionFile(msg: any): void {
  const sp = msg.sessionPath;
  const sessionFile = msg.details?.sessionFile;
  if (!sp || !sessionFile) return;
  useStore.getState().upsertSessionRegistryFile?.(sp, sessionFile);
}

function applyContentBlockSessionFile(msg: any): void {
  const sp = msg.sessionPath;
  const block = msg.block;
  if (!sp || block?.type !== 'file') return;
  useStore.getState().upsertSessionRegistryFile?.(sp, {
    id: block.fileId,
    fileId: block.fileId,
    filePath: block.filePath,
    label: block.label,
    ext: block.ext,
    mime: block.mime,
    kind: block.kind,
    storageKind: block.storageKind,
    presentation: block.presentation,
    listed: block.listed,
    status: block.status,
    missingAt: block.missingAt,
    mtimeMs: block.mtimeMs,
    size: block.size,
    version: block.version,
    resource: block.resource,
    origin: block.origin,
    operations: block.operations,
  });
}
