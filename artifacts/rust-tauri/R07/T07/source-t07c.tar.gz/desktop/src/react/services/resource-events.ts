import { lingxiFetch } from '../hooks/use-hana-fetch';
import { useStore } from '../stores';
import { appendConnectionAuth, buildConnectionUrl, resolveServerConnection, type ServerConnection } from './server-connection';

export type ResourceRef =
  | { kind: 'local-file'; path: string }
  | { kind: 'mount'; mountId: string; path: string };

type WatchEntry = {
  ref: ResourceRef;
  refCount: number;
  subscriptionId: string | null;
  /** 服务端实际 watch 的解析路径（realpath 后，从 subscribe 响应的 resourceKeys 习得）。 */
  resolvedPath: string | null;
  disposed: boolean;
  released: boolean;
  ready: Promise<void>;
  owner: ServerConnection | null;
  unsubscribeOwner?: () => void;
  generation: number;
  paused: boolean;
};

const watches = new Map<string, WatchEntry>();

type ResourceEvent = {
  type?: string;
  sequence?: number;
  [key: string]: unknown;
};

type ResourceEventFetch = (
  path: string,
  opts?: RequestInit & { timeout?: number; throwOnHttpError?: boolean },
) => Promise<{ json: () => Promise<any> }>;

type ResourceEventClientOptions = {
  fetchImpl?: ResourceEventFetch;
  applyEvent?: (event: ResourceEvent) => void;
  resubscribeWatches?: () => Promise<void> | void;
};

type ForegroundCatchUpOptions = {
  windowObj?: Pick<Window, 'addEventListener' | 'removeEventListener'> | null;
  documentObj?: Pick<Document, 'addEventListener' | 'removeEventListener' | 'visibilityState'> | null;
  catchUp?: () => Promise<unknown> | unknown;
  minIntervalMs?: number;
  now?: () => number;
};

export function createResourceEventClient({
  fetchImpl = lingxiFetch,
  applyEvent,
  resubscribeWatches,
}: ResourceEventClientOptions = {}) {
  let lastSeenSequence = 0;

  const handleEvent = (event: ResourceEvent | null | undefined): void => {
    if (!isResourceEvent(event)) return;
    if (Number.isFinite(event.sequence) && Number(event.sequence) > lastSeenSequence) {
      lastSeenSequence = Math.floor(Number(event.sequence));
    }
  };

  const catchUpAfterReconnect = async (options: { applyEvent?: (event: ResourceEvent) => void } = {}) => {
    const res = await fetchImpl(`/api/resource-io/events?since=${lastSeenSequence}`, {
      method: 'GET',
      throwOnHttpError: false,
    });
    const data = await res.json();
    if (data?.stale || (Number.isFinite(data?.latestSequence) && Number(data.latestSequence) < lastSeenSequence)) {
      await resubscribeWatches?.();
      if (Number.isFinite(data.latestSequence) && Number(data.latestSequence) >= 0) {
        lastSeenSequence = Math.floor(Number(data.latestSequence));
      }
      return data;
    }

    const handler = options.applyEvent || applyEvent;
    for (const event of Array.isArray(data?.events) ? data.events : []) {
      handleEvent(event);
      handler?.(event);
    }
    if (Number.isFinite(data?.latestSequence) && Number(data.latestSequence) > lastSeenSequence) {
      lastSeenSequence = Math.floor(Number(data.latestSequence));
    }
    return data;
  };

  return {
    handleEvent,
    catchUpAfterReconnect,
    lastSeenSequence: () => lastSeenSequence,
  };
}

const resourceEventClient = createResourceEventClient({
  fetchImpl: lingxiFetch,
  resubscribeWatches: resubscribeActiveWatches,
});

function normalizeResourceRef(ref: ResourceRef): ResourceRef {
  if (ref.kind === 'local-file') {
    return { kind: 'local-file', path: ref.path };
  }
  return {
    kind: 'mount',
    mountId: ref.mountId,
    path: String(ref.path || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, ''),
  };
}

export function resourceWatchKey(ref: ResourceRef): string {
  const normalized = normalizeResourceRef(ref);
  if (normalized.kind === 'local-file') {
    const slashed = normalized.path.replace(/\\/g, '/').replace(/\/+$/g, '');
    return `local-file:${/^[A-Za-z]:/.test(slashed) ? slashed.toLowerCase() : slashed}`;
  }
  return `mount:${normalized.mountId}:${normalized.path}`;
}

export function retainResourceWatch(ref: ResourceRef): () => void {
  const normalizedRef = normalizeResourceRef(ref);
  const key = resourceWatchKey(normalizedRef);
  const existing = watches.get(key);
  if (existing) {
    existing.refCount += 1;
    return () => releaseResourceWatch(key, existing);
  }

  const entry: WatchEntry = {
    ref: normalizedRef,
    refCount: 1,
    subscriptionId: null,
    resolvedPath: null,
    disposed: false,
    released: false,
    ready: Promise.resolve(),
    owner: null,
    generation: 0,
    paused: false,
  };
  const connection = resolveServerConnection(useStore.getState());
  if (connection?.serverNodeKind === 'lingxi-service') {
    const ownerKey = JSON.stringify(connection);
    entry.owner = JSON.parse(ownerKey);
    entry.unsubscribeOwner = useStore.subscribe(() => {
      if (JSON.stringify(resolveServerConnection(useStore.getState())) === ownerKey) return;
      entry.disposed = true;
      entry.generation++;
      entry.unsubscribeOwner?.();
      if (watches.get(key) === entry) watches.delete(key);
      releaseEntry(entry);
    });
  }
  entry.ready = subscribeEntry(entry);
  watches.set(key, entry);
  return () => releaseResourceWatch(key, entry);
}

/** 取消订阅也须使用创建它的原连接，不能把旧订阅编号发到新服务。 */
function watchRequest(entry: WatchEntry, path: string, opts: RequestInit): Promise<{ json: () => Promise<any> }> {
  if (!entry.owner) return lingxiFetch(path, { ...opts, throwOnHttpError: false });
  return fetch(buildConnectionUrl(entry.owner, `/lingxi/v1${path.slice('/api'.length)}`), {
    ...opts, headers: appendConnectionAuth(entry.owner, opts.headers), signal: AbortSignal.timeout(30_000),
  }).then(response => {
    if (!response.ok) throw new Error(`资源订阅请求失败 (${response.status})`);
    return response;
  });
}

/**
 * 从 subscribe 响应里习得服务端实际 watch 的解析路径。
 * local_fs provider 会对路径做 realpath（macOS：/tmp → /private/tmp），而 store 中的
 * 工作台根路径是配置/披露的未解析形式；watch 事件只携带解析后的路径。
 */
function resolvedLocalPathFromSubscription(ref: ResourceRef, data: any): string | null {
  if (ref.kind !== 'local-file') return null;
  const keys = Array.isArray(data?.resourceKeys) ? data.resourceKeys : [];
  for (const key of keys) {
    if (typeof key !== 'string' || !key.startsWith('local_fs:')) continue;
    const resolved = key.slice('local_fs:'.length).trim();
    if (resolved) return resolved;
  }
  return null;
}

function subscribeEntry(entry: WatchEntry): Promise<void> {
  const generation = ++entry.generation;
  entry.released = false;
  return watchRequest(entry, '/api/resource-io/subscribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ purpose: 'resource-watch', resources: [entry.ref] }),
  })
    .then(res => res.json())
    .then((data) => {
      if (typeof data?.subscriptionId === 'string') {
        if (entry.disposed || entry.paused || entry.generation !== generation) {
          return releaseSubscription(entry, data.subscriptionId);
        }
        entry.subscriptionId = data.subscriptionId;
        entry.resolvedPath = resolvedLocalPathFromSubscription(entry.ref, data);
      } else {
        console.warn('[resource-events] watch failed:', data?.error || entry.ref);
      }
    })
    .catch((err) => {
      if (!entry.disposed) console.warn('[resource-events] watch failed:', err);
    });
}

export function retainLocalFileResourceWatch(filePath: string): () => void {
  return retainResourceWatch({ kind: 'local-file', path: filePath });
}

/**
 * 本地路径在服务端被解析（realpath）后的别名；路径本身已是解析形式时返回 null。
 * watch 事件只带解析后路径，工作台根路径做前缀归位时用它兜底，避免事件被静默丢弃。
 */
export function resolvedLocalPathAlias(filePath: string | null | undefined): string | null {
  if (typeof filePath !== 'string' || !filePath.trim()) return null;
  const key = resourceWatchKey({ kind: 'local-file', path: filePath });
  const resolved = watches.get(key)?.resolvedPath || null;
  if (!resolved) return null;
  const normalized = normalizeResourceRef({ kind: 'local-file', path: resolved });
  return resourceWatchKey(normalized) === key ? null : normalized.path;
}

function releaseResourceWatch(key: string, ownedEntry: WatchEntry): void {
  const entry = watches.get(key);
  if (!entry || entry !== ownedEntry) return;
  if (entry.refCount > 1) {
    entry.refCount -= 1;
    return;
  }
  watches.delete(key);
  entry.disposed = true;
  entry.generation++;
  entry.unsubscribeOwner?.();
  void entry.ready.then(() => releaseEntry(entry));
}

function releaseEntry(entry: WatchEntry): void {
  if (entry.released || !entry.subscriptionId) return;
  entry.released = true;
  const subscriptionId = entry.subscriptionId;
  entry.subscriptionId = null;
  void releaseSubscription(entry, subscriptionId);
}

function releaseSubscription(entry: WatchEntry, subscriptionId: string): Promise<void> {
  return watchRequest(entry, `/api/resource-io/subscriptions/${encodeURIComponent(subscriptionId)}`, {
    method: 'DELETE',
  }).then(() => undefined).catch((err) => {
    console.warn('[resource-events] unwatch failed:', err);
  });
}

/** 断连时暂停正式订阅；保留页面引用，重连后重新申请，迟到收据按原服务回收。 */
export function pauseRustResourceWatches(connection: ServerConnection): void {
  const key = JSON.stringify(connection);
  for (const entry of watches.values()) {
    if (!entry.owner || JSON.stringify(entry.owner) !== key) continue;
    entry.paused = true;
    entry.generation++;
    releaseEntry(entry);
  }
}

export async function resubscribeActiveWatches(): Promise<void> {
  const entries = [...watches.values()].filter(entry => !entry.disposed);
  await Promise.all(entries.map(async (entry) => {
    const previousSubscriptionId = entry.subscriptionId;
    entry.subscriptionId = null;
    entry.generation++;
    entry.paused = false;
    if (previousSubscriptionId) {
      await releaseSubscription(entry, previousSubscriptionId);
    }
    if (!entry.disposed && !entry.paused) entry.ready = subscribeEntry(entry);
    await entry.ready;
  }));
}

function isResourceEvent(event: ResourceEvent | null | undefined): event is ResourceEvent {
  return event?.type === 'resource.changed' || event?.type === 'resource.deleted' || event?.type === 'resource.renamed';
}

export function recordResourceEventCursor(event: ResourceEvent | null | undefined): void {
  resourceEventClient.handleEvent(event);
}

export function catchUpResourceEventsAfterReconnect(applyEvent?: (event: ResourceEvent) => void): Promise<unknown> {
  return resourceEventClient.catchUpAfterReconnect({ applyEvent });
}

export function bindResourceEventForegroundCatchUp(
  applyEvent?: (event: ResourceEvent) => void,
  options: ForegroundCatchUpOptions = {},
): () => void {
  const windowObj = options.windowObj ?? (typeof window !== 'undefined' ? window : null);
  const documentObj = options.documentObj ?? (typeof document !== 'undefined' ? document : null);
  if (!windowObj || !documentObj) return () => {};

  const minIntervalMs = Math.max(0, Math.floor(Number(options.minIntervalMs ?? 1000) || 0));
  const now = options.now ?? (() => Date.now());
  const catchUp = options.catchUp ?? (() => catchUpResourceEventsAfterReconnect(applyEvent));
  let inFlight = false;
  let lastStartedAt = 0;

  const run = () => {
    if (documentObj.visibilityState === 'hidden') return;
    const startedAt = now();
    if (inFlight || (lastStartedAt && startedAt - lastStartedAt < minIntervalMs)) return;
    inFlight = true;
    lastStartedAt = startedAt;
    Promise.resolve(catchUp())
      .catch((err) => {
        console.warn('[resource-events] foreground catch-up failed:', err);
      })
      .finally(() => {
        inFlight = false;
      });
  };

  const onVisibilityChange = () => {
    if (documentObj.visibilityState === 'visible') run();
  };

  windowObj.addEventListener('focus', run);
  documentObj.addEventListener('visibilitychange', onVisibilityChange);
  return () => {
    windowObj.removeEventListener('focus', run);
    documentObj.removeEventListener('visibilitychange', onVisibilityChange);
  };
}
