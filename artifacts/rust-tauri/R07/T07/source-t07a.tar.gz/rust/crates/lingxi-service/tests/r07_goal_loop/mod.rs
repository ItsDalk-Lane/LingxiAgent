//! R07-T07-δ goal + /loop + loop_control 集成验收（对照 T07_STATUS.md 的
//! 「δ 验收测试形态」登记）：
//! - goal 工具六动作（create/status/pause/resume/complete/drop）经真 Run 的
//!   工具调用闭环；替身逐轮上报 token usage → 预算累计 → 超支事件恰好一次
//!   （app_events 的 goal_over_budget 有且仅有一条；模型可见面 steering
//!   `<hana-goal-over-budget>` 随下一轮提交送达替身）。
//! - /loop 五子命令（启动/status/pause/resume/stop）作用于真会话：kickoff
//!   驱动一个替身模型轮；轮内 loop_control schedule 设闹钟 → 闹钟触发唤醒
//!   轮 → 轮内 loop_control complete → /loop status 可见 completed 与摘要。
//!
//! 模型替身的行为纪律与 r07_automation_flow 一致：路由只看提交内容（命令
//! JSON / 循环消息标记），不读工作区、不知道任何运行内幕；工具结果经
//! input.prior 的 ToolResult 观察。与自动化用例的唯一差异：本文件的替身
//! 每轮都上报 usage（goal 预算进账的观察缝）。

use lingxi_kernel::{
    model_exchange::{ExchangeItem, ModelTurnInput},
    ports::{
        ProviderDescriptor, ProviderTurn, ProviderTurnResult, StoragePort, ToolOutcome,
        ToolRequest, TurnDeltaSink, TurnProviderPort,
    },
    toolcatalog::{SchemaBudget, ToolRegistry},
};
use lingxi_protocol::{ContentBlock, ModelCallId, NormalizedMessage, UsageRecord};
use lingxi_service::{
    approval_service::ApprovalService,
    inject::{ManualClock, ServiceClock},
    loopx::LoopStatus,
    prepare_layout,
    toolgateway::ToolInvocationGateway,
    HomeSource, NetworkMode, ServiceConfig, ServiceDeps, ServiceState,
};
use lingxi_test_guard as _;
use serde_json::{json, Value};
use std::{
    path::PathBuf,
    sync::{
        atomic::{AtomicUsize, Ordering},
        Arc, Mutex,
    },
};

/// 确定性替身：命令 JSON → 工具调用；循环唤醒消息 → loop_control；其余 →
/// 文本终稿。每一轮都上报 30+30 token（goal 预算进账的观察样本）。
#[derive(Default)]
struct Provider {
    calls: AtomicUsize,
    submissions: Mutex<Vec<String>>,
    results: Mutex<Vec<Value>>,
}

impl Provider {
    fn submissions(&self) -> Vec<String> {
        self.submissions.lock().unwrap().clone()
    }
    fn last_result(&self) -> Value {
        self.results.lock().unwrap().last().unwrap().clone()
    }
}

impl TurnProviderPort for Provider {
    fn descriptor(&self) -> ProviderDescriptor {
        ProviderDescriptor {
            provider: "r07.fixture".into(),
            model: "deterministic".into(),
            operation: "chat".into(),
        }
    }
    fn next_turn<'a>(
        &'a self,
        ctx: &'a lingxi_kernel::RunContext,
        call: &'a ModelCallId,
        input: &'a ModelTurnInput,
        _sink: &'a dyn TurnDeltaSink,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ProviderTurnResult> + Send + 'a>> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        let submission = input.submission.clone();
        self.submissions.lock().unwrap().push(submission.clone());
        Box::pin(async move {
            if input.turn == 1 {
                // 命令通道：用户文本整体是 {"tool":..., "args":...}；超支
                // steering 会以 "\n\n[steering]\n" 后缀拼进提交，先剥掉再解析。
                let head = submission
                    .split("\n\n[steering]\n")
                    .next()
                    .unwrap_or(submission.as_str());
                let command = serde_json::from_str::<Value>(head).ok().or_else(|| {
                    head.rsplit("\n\n")
                        .find_map(|part| serde_json::from_str::<Value>(part).ok())
                });
                if let Some(command) = command {
                    if let Some(tool) = command["tool"].as_str() {
                        return ProviderTurnResult::of_ctx_with_usage(
                            ctx,
                            ProviderTurn::ToolRequests {
                                requests: vec![ToolRequest::from_effective_arguments(
                                    format!("tool:first-party:{tool}"),
                                    command["args"].clone(),
                                    &SchemaBudget::default(),
                                )
                                .unwrap()],
                                content: vec![],
                            },
                            UsageRecord {
                                input_tokens: 30,
                                output_tokens: 30,
                            },
                        );
                    }
                }
                // 循环轮路由：resume 轮设闹钟（60s = 现役 min_delay 钳制值），
                // 闹钟唤醒轮收束循环。理由词是两轮之间的确定性区分符。
                if submission.contains("<hana-loop kind=\"wakeup\">") {
                    let args = if submission.contains("Reason: loop resumed") {
                        json!({"action":"schedule","delay_seconds":60,"reason":"poke-check"})
                    } else if submission.contains("Reason: poke-check") {
                        json!({"action":"complete","reason":"目标达成"})
                    } else {
                        json!({"action":"complete","reason":"未知唤醒直接收束"})
                    };
                    return ProviderTurnResult::of_ctx_with_usage(
                        ctx,
                        ProviderTurn::ToolRequests {
                            requests: vec![ToolRequest::from_effective_arguments(
                                "tool:first-party:loop_control".to_string(),
                                args,
                                &SchemaBudget::default(),
                            )
                            .unwrap()],
                            content: vec![],
                        },
                        UsageRecord {
                            input_tokens: 30,
                            output_tokens: 30,
                        },
                    );
                }
            }
            if let Some(result) = input.prior.iter().rev().find_map(|entry| {
                if let ExchangeItem::ToolResult { outcome, .. } = entry {
                    Some(match outcome {
                        ToolOutcome::Success { result } => {
                            let text = result
                                .content
                                .iter()
                                .find_map(|block| match block {
                                    ContentBlock::Text { text } => Some(text.clone()),
                                    _ => None,
                                })
                                .unwrap_or_default();
                            json!({"ok":true,"text":text,"details":result.details})
                        }
                        ToolOutcome::Failed { error } => {
                            json!({"ok":false,"error":error.message})
                        }
                        _ => json!({"ok":false}),
                    })
                } else {
                    None
                }
            }) {
                self.results.lock().unwrap().push(result);
            }
            ProviderTurnResult::of_ctx_with_usage(
                ctx,
                ProviderTurn::Final {
                    message: NormalizedMessage {
                        role: "assistant".into(),
                        content: vec![ContentBlock::Text {
                            text: "合成应答".into(),
                        }],
                        model_call_id: Some(call.clone()),
                    },
                },
                UsageRecord {
                    input_tokens: 30,
                    output_tokens: 30,
                },
            )
        })
    }
}

struct Harness {
    home: PathBuf,
    state: ServiceState,
    clock: Arc<ManualClock>,
    provider: Arc<Provider>,
    url: String,
    token: String,
    stop: tokio::sync::oneshot::Sender<()>,
    task: tokio::task::JoinHandle<()>,
}

impl Harness {
    /// sessions: (session_id, authorized_folders)——授权目录须已存在。
    async fn boot(sessions: &[(&str, &[String])]) -> Self {
        let _ = tracing_subscriber::fmt()
            .with_env_filter("lingxi_service=debug")
            .with_test_writer()
            .try_init();
        let home = std::env::temp_dir().join(format!(
            "lingxi-r07-goal-loop-{}",
            lingxi_adapters::storage::agent_memory::random_token_suffix()
        ));
        std::fs::create_dir_all(home.join("agents/lingxi")).unwrap();
        std::fs::write(
            home.join("agents/lingxi/config.yaml"),
            "agent:\n  name: 合成助手\nmemory:\n  enabled: false\n",
        )
        .unwrap();
        let home = home.canonicalize().unwrap();
        let layout = prepare_layout(&home).unwrap();
        let clock = Arc::new(ManualClock::new(1_800_000_000_000));
        let provider = Arc::new(Provider::default());
        let approvals = Arc::new(ApprovalService::new(clock.clone()));
        let gateway = Arc::new(ToolInvocationGateway::new(
            Arc::new(ToolRegistry::new()),
            approvals,
            clock.clone(),
            SchemaBudget::default(),
            300_000,
            1000,
        ));
        let state = ServiceState::bootstrap_with_deps(
            ServiceConfig {
                bind_addr: "127.0.0.1:0".parse().unwrap(),
                data_home: home.clone(),
                home_source: HomeSource::Cli,
                network_mode: NetworkMode::Loopback,
                shutdown_timeout_ms: 5000,
            },
            &layout,
            ServiceDeps {
                clock: clock.clone(),
                turn_provider: Some(provider.clone()),
                tool_gateway: Some(gateway),
                ..ServiceDeps::default()
            },
        )
        .await
        .unwrap();
        let token = state.auth().local_token();
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let (stop, done) = tokio::sync::oneshot::channel();
        let router = lingxi_service::build_router(state.clone());
        let task = tokio::spawn(async move {
            axum::serve(
                listener,
                router.into_make_service_with_connect_info::<std::net::SocketAddr>(),
            )
            .with_graceful_shutdown(async {
                let _ = done.await;
            })
            .await
            .unwrap();
        });
        for (session, folders) in sessions {
            state
                .session_admin()
                .create_session(
                    session,
                    "lingxi",
                    lingxi_kernel::LOCAL_OWNER_SUBJECT,
                    "合成会话",
                    Some("operate"),
                    folders,
                    true,
                    clock.now_unix_ms(),
                )
                .await
                .unwrap();
        }
        Self {
            home,
            state,
            clock,
            provider,
            url: format!("http://{addr}"),
            token,
            stop,
            task,
        }
    }
    async fn request(&self, method: &str, path: &str, body: Value) -> (u16, Value) {
        let client = reqwest::Client::new();
        let result = client
            .request(method.parse().unwrap(), format!("{}{path}", self.url))
            .bearer_auth(&self.token)
            .json(&body)
            .send()
            .await
            .unwrap();
        let status = result.status().as_u16();
        let body = result.json().await.unwrap();
        (status, body)
    }
    async fn slash(&self, session: &str, text: &str) -> Value {
        let (status, body) = self
            .request(
                "POST",
                &format!("/lingxi/v1/sessions/{session}/slash"),
                json!({"text": text}),
            )
            .await;
        assert_eq!(status, 200, "{body}");
        body
    }
    async fn close(self) -> PathBuf {
        let _ = self.stop.send(());
        self.task.await.unwrap();
        self.state.storage().close().await.unwrap();
        self.home
    }
}

/// 真 Run 驱动一次工具调用并等到终态。
async fn chat(h: &Harness, session: &str, input: Value) -> String {
    let principal = h
        .state
        .auth()
        .authenticate(
            Some(&format!("Bearer {}", h.token)),
            None,
            false,
            lingxi_service::ConnectionKind::Local,
        )
        .unwrap();
    let accepted = h
        .state
        .sessions()
        .execute_background_for(
            h.state.storage(),
            h.state.events(),
            h.state.runs(),
            h.state.background(),
            &principal,
            session,
            &lingxi_service::ExecuteSubmission::plain(&input.to_string()),
            h.clock.now_unix_ms(),
        )
        .await
        .unwrap();
    tokio::time::timeout(std::time::Duration::from_secs(10), async {
        loop {
            let run = h
                .state
                .storage()
                .load_run(&lingxi_protocol::RunId::new(&accepted.run_id))
                .await
                .unwrap()
                .unwrap();
            if run.status.is_terminal() {
                assert_eq!(run.status, lingxi_protocol::RunStatus::Completed);
                break;
            }
            tokio::time::sleep(std::time::Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("真实Run必须结束");
    accepted.run_id
}

async fn wait_until(what: &str, timeout_secs: u64, mut pred: impl FnMut() -> bool) {
    tokio::time::timeout(std::time::Duration::from_secs(timeout_secs), async move {
        loop {
            if pred() {
                return;
            }
            tokio::time::sleep(std::time::Duration::from_millis(50)).await;
        }
    })
    .await
    .unwrap_or_else(|_| panic!("{what} 未在 {timeout_secs}s 内满足"));
}

fn goal_over_budget_events(h: &Harness) -> Vec<Value> {
    h.state.app_events().since(0)["events"]
        .as_array()
        .unwrap()
        .iter()
        .filter(|event| event["type"] == "goal_over_budget")
        .cloned()
        .collect()
}

#[tokio::test]
async fn goal_six_actions_close_loop_and_over_budget_fires_exactly_once() {
    let h = Harness::boot(&[("goal-session", &[])]).await;

    // create：token 预算 50。进账时序（账本落盘钩在模型调用收束时触发，
    // 工具执行在其后）：本 run 第一轮的 60 token 落账时 goal 尚不存在
    // （不记），create 执行后第二轮的 60 进账 → 60 ≥ 50 越限，事件在
    // 本 run 内发出。
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"create","name":"整备资料","token_budget":50}}),
    )
    .await;
    let created = h.provider.last_result();
    assert_eq!(created["ok"], true, "{created}");
    assert_eq!(created["details"]["goal"]["name"], "整备资料");
    assert_eq!(created["details"]["goal"]["tokenBudget"], 50);
    assert_eq!(created["details"]["goal"]["status"], "active");
    assert_eq!(created["details"]["goal"]["tokensUsed"], 0);

    // 超支事件恰好一次（create run 的第二轮进账 60 越限时触发）。
    let events = goal_over_budget_events(&h);
    assert_eq!(events.len(), 1, "{events:?}");
    assert_eq!(events[0]["payload"]["name"], "整备资料");
    assert_eq!(events[0]["payload"]["kind"], "tokens");
    assert_eq!(events[0]["payload"]["tokenBudget"], 50);
    assert_eq!(events[0]["payload"]["tokensUsed"], 60);
    assert_eq!(events[0]["payload"]["sessionId"], "goal-session");

    // status：本 run 第一轮再进账 60（累计恰为 120 时读取），overBudget
    // 保持；且模型可见面的 <hana-goal-over-budget> steering 随本论提交送达
    // 替身。
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"status"}}),
    )
    .await;
    let status = h.provider.last_result();
    assert_eq!(status["ok"], true, "{status}");
    assert_eq!(status["details"]["hasGoal"], true);
    assert_eq!(status["details"]["goal"]["overBudget"], true);
    assert_eq!(status["details"]["goal"]["tokensUsed"], 120);
    assert!(
        h.provider.submissions().iter().any(|s| s.contains(
            "<hana-goal-over-budget goal=\"整备资料\">token budget 50 exceeded (used 60)."
        )),
        "超支 steering 必须随下一轮送达模型"
    );
    // 又两轮进账（240 累计）后仍然只有一条超支事件——「恰好一次」。
    assert_eq!(goal_over_budget_events(&h).len(), 1);

    // pause / resume。
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"pause"}}),
    )
    .await;
    let paused = h.provider.last_result();
    assert_eq!(paused["ok"], true, "{paused}");
    assert_eq!(paused["details"]["ok"], true);
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"resume"}}),
    )
    .await;
    let resumed = h.provider.last_result();
    assert_eq!(resumed["ok"], true, "{resumed}");
    assert_eq!(resumed["details"]["ok"], true);

    // complete：收官文本含最终读数；此后 goal 不再活跃。
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"complete"}}),
    )
    .await;
    let completed = h.provider.last_result();
    assert_eq!(completed["ok"], true, "{completed}");
    assert_eq!(completed["details"]["ok"], true);
    assert!(completed["text"]
        .as_str()
        .unwrap()
        .contains("goal completed"));

    // create 可替换已收官 goal；drop 收尾；status 对收官 goal 保持可读
    // （现役 readout 语义：status 回报最后一任 goal 的终态与读数）。
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"create","name":"临时","token_budget":1000}}),
    )
    .await;
    let recreated = h.provider.last_result();
    assert_eq!(recreated["ok"], true, "{recreated}");
    assert_eq!(recreated["details"]["goal"]["name"], "临时");
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"drop"}}),
    )
    .await;
    let dropped = h.provider.last_result();
    assert_eq!(dropped["ok"], true, "{dropped}");
    assert_eq!(dropped["details"]["ok"], true);
    assert_eq!(dropped["text"].as_str().unwrap(), "goal dropped");
    chat(
        &h,
        "goal-session",
        json!({"tool":"goal","args":{"action":"status"}}),
    )
    .await;
    let readout = h.provider.last_result();
    assert_eq!(readout["details"]["hasGoal"], true, "{readout}");
    assert_eq!(readout["details"]["goal"]["status"], "dropped");
    assert_eq!(readout["details"]["goal"]["name"], "临时");
    assert_eq!(goal_over_budget_events(&h).len(), 1);

    let root = h.close().await;
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn loop_slash_lifecycle_alarm_wakeup_and_loop_control() {
    let h = Harness::boot(&[("loop-session", &[])]).await;
    let controller = &h.state.loop_services().controller;

    // 启动：kickoff 驱动一个替身模型轮（替身直接终稿，不调工具）。
    let started = h.slash("loop-session", "/loop 盯一下合成队列").await;
    assert_eq!(started["results"][0]["level"], "success", "{started}");
    assert!(
        started["results"][0]["text"]
            .as_str()
            .unwrap()
            .contains("循环已启动"),
        "{started}"
    );
    wait_until("kickoff 轮收束", 10, || {
        controller
            .tool_status("loop-session")
            .is_some_and(|record| record.turn_count == 1)
    })
    .await;
    let record = controller.tool_status("loop-session").unwrap();
    assert_eq!(record.status, LoopStatus::Running);
    assert_eq!(record.turn_count, 1);

    // status：running 可见。
    let status = h.slash("loop-session", "/loop status").await;
    let text = status["results"][0]["text"].as_str().unwrap();
    assert!(text.contains("循环状态：running"), "{text}");
    assert!(text.contains("轮数：1/50"), "{text}");
    assert!(text.contains("任务：盯一下合成队列"), "{text}");

    // pause → resume：暂停期间闹钟槽清空；resume 轮替身调 loop_control
    // schedule 设 60s 闹钟（现役 min_delay 钳制值，真实等待触发）。
    let paused = h.slash("loop-session", "/loop pause").await;
    assert_eq!(paused["results"][0]["level"], "success", "{paused}");
    assert_eq!(
        controller.tool_status("loop-session").unwrap().status,
        LoopStatus::Paused
    );
    let status = h.slash("loop-session", "/loop status").await;
    assert!(
        status["results"][0]["text"]
            .as_str()
            .unwrap()
            .contains("循环状态：paused（user）"),
        "{status}"
    );
    let resumed = h.slash("loop-session", "/loop resume").await;
    assert_eq!(resumed["results"][0]["level"], "success", "{resumed}");
    wait_until("resume 轮设好闹钟", 10, || {
        controller
            .tool_status("loop-session")
            .is_some_and(|record| record.status == LoopStatus::Running && record.alarm.is_some())
            && h.provider
                .results
                .lock()
                .unwrap()
                .last()
                .is_some_and(|result| {
                    result["text"]
                        .as_str()
                        .is_some_and(|text| text.contains("Wakeup scheduled in 60s"))
                })
            && !h
                .state
                .sessions()
                .session_supervisor()
                .is_busy("loop-session")
    })
    .await;
    let schedule_result = h.provider.last_result();
    assert_eq!(schedule_result["ok"], true, "{schedule_result}");
    assert!(
        schedule_result["text"]
            .as_str()
            .unwrap()
            .contains("Wakeup scheduled in 60s"),
        "{schedule_result}"
    );

    // 闹钟真实触发 → 唤醒轮替身调 loop_control complete → 循环收束。
    wait_until("闹钟唤醒轮收束循环", 100, || {
        controller
            .tool_status("loop-session")
            .is_some_and(|record| record.status == LoopStatus::Completed)
            && h.provider
                .results
                .lock()
                .unwrap()
                .last()
                .is_some_and(|result| result["text"] == "Loop completed and closed.")
            && !h
                .state
                .sessions()
                .session_supervisor()
                .is_busy("loop-session")
    })
    .await;
    let complete_result = h.provider.last_result();
    assert_eq!(complete_result["ok"], true, "{complete_result}");
    assert_eq!(
        complete_result["text"].as_str().unwrap(),
        "Loop completed and closed."
    );

    // complete 后状态可见：completed + 摘要。
    let status = h.slash("loop-session", "/loop status").await;
    let text = status["results"][0]["text"].as_str().unwrap();
    assert!(text.contains("循环状态：completed"), "{text}");
    assert!(text.contains("完成摘要：目标达成"), "{text}");

    // stop 子命令对已收束循环依然响亮可用（现役命令面语义）。
    let stopped = h.slash("loop-session", "/loop stop").await;
    assert_eq!(stopped["results"][0]["level"], "success", "{stopped}");
    assert_eq!(
        controller.tool_status("loop-session").unwrap().status,
        LoopStatus::Stopped
    );

    // 替身轮次与路由证据：kickoff 一轮、resume 一轮、闹钟唤醒一轮，共 5 次
    // 模型调用（1+2+2），三类循环消息逐一出现。
    let submissions = h.provider.submissions();
    assert_eq!(h.provider.calls.load(Ordering::SeqCst), 5);
    assert!(submissions
        .iter()
        .any(|s| s.contains("<hana-loop kind=\"kickoff\">") && s.contains("Task: 盯一下合成队列")));
    assert!(submissions
        .iter()
        .any(|s| s.contains("kind=\"wakeup\"") && s.contains("Reason: loop resumed")));
    assert!(submissions
        .iter()
        .any(|s| s.contains("kind=\"wakeup\"") && s.contains("Reason: poke-check")));

    let root = h.close().await;
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test]
async fn goal_corrupt_sidecar_is_tool_failure_through_real_run_and_never_replaced() {
    let h = Harness::boot(&[("goal-corrupt", &[])]).await;
    let dir = h.home.join("goal-sidecars");
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("goal-corrupt.goal.json");
    std::fs::write(&path, b"{damaged goal original").unwrap();
    for action in ["status", "create", "pause", "resume", "complete", "drop"] {
        chat(
            &h,
            "goal-corrupt",
            json!({"tool":"goal","args":{"action":action,"token_budget":10}}),
        )
        .await;
        let result = h.provider.last_result();
        assert_eq!(result["ok"], false, "{action}: {result}");
        assert!(
            result["error"]
                .as_str()
                .unwrap()
                .contains("goal storage is corrupt"),
            "{result}"
        );
        assert_eq!(std::fs::read(&path).unwrap(), b"{damaged goal original");
    }
    assert!(goal_over_budget_events(&h).is_empty());
    h.close().await;
}

#[tokio::test]
async fn goal_write_fault_is_tool_failure_and_no_budget_notification_through_real_run() {
    let h = Harness::boot(&[("goal-write-fault", &[])]).await;
    chat(
        &h,
        "goal-write-fault",
        json!({"tool":"goal","args":{"action":"create","token_budget":10000}}),
    )
    .await;
    let path = h.home.join("goal-sidecars/goal-write-fault.goal.json");
    let before = std::fs::read(&path).unwrap();
    let recovery = h.home.join("file-recovery-records");
    if recovery.exists() {
        std::fs::rename(&recovery, h.home.join("fixture-retained-recovery-records")).unwrap();
    }
    std::fs::write(&recovery, b"blocker").unwrap();
    chat(
        &h,
        "goal-write-fault",
        json!({"tool":"goal","args":{"action":"pause"}}),
    )
    .await;
    let result = h.provider.last_result();
    assert_eq!(result["ok"], false, "{result}");
    assert!(
        result["error"]
            .as_str()
            .unwrap()
            .contains("goal storage write failed"),
        "{result}"
    );
    assert_eq!(std::fs::read(&path).unwrap(), before);
    assert!(goal_over_budget_events(&h).is_empty());
    h.close().await;
}

#[tokio::test]
async fn goal_preferences_read_is_pure_and_single_edit_preserves_budget_and_unknown_settings() {
    let h = Harness::boot(&[("goal-prefs", &[])]).await;
    let preferences = h.home.join("user/preferences.json");
    std::fs::create_dir_all(preferences.parent().unwrap()).unwrap();
    std::fs::write(
        &preferences,
        serde_json::to_vec(&json!({"unrelated":{"keep":true}})).unwrap(),
    )
    .unwrap();
    let before = std::fs::read(&preferences).unwrap();
    let (status, defaults) = h
        .request("GET", "/lingxi/v1/preferences/goal", Value::Null)
        .await;
    assert_eq!(status, 200, "{defaults}");
    assert_eq!(defaults["goal"]["enabled"], true);
    assert_eq!(std::fs::read(&preferences).unwrap(), before);
    let (status, saved) = h
        .request(
            "PUT",
            "/lingxi/v1/preferences/goal",
            json!({"enabled":false,"default_token_budget":500,"custom_compat":"keep"}),
        )
        .await;
    assert_eq!(status, 200, "{saved}");
    let (status, saved) = h
        .request(
            "PUT",
            "/lingxi/v1/preferences/goal",
            json!({"enabled":true}),
        )
        .await;
    assert_eq!(status, 200, "{saved}");
    let (status, read) = h
        .request("GET", "/lingxi/v1/preferences/goal", Value::Null)
        .await;
    assert_eq!(status, 200, "{read}");
    assert_eq!(read["goal"]["enabled"], true);
    assert_eq!(read["goal"]["default_token_budget"], 500);
    assert_eq!(read["goal"]["custom_compat"], "keep");
    let stored: Value = serde_json::from_slice(&std::fs::read(&preferences).unwrap()).unwrap();
    assert_eq!(stored["unrelated"]["keep"], true);
    chat(
        &h,
        "goal-prefs",
        json!({"tool":"goal","args":{"action":"create","name":"使用保存预算"}}),
    )
    .await;
    assert_eq!(
        h.provider.last_result()["details"]["goal"]["tokenBudget"],
        500
    );
    let before_invalid = std::fs::read(&preferences).unwrap();
    let (status, _) = h
        .request(
            "PUT",
            "/lingxi/v1/preferences/goal",
            json!({"enabled":"wrong"}),
        )
        .await;
    assert_eq!(status, 400);
    assert_eq!(std::fs::read(&preferences).unwrap(), before_invalid);
    let root = h.close().await;
    std::fs::remove_dir_all(root).unwrap();
}
