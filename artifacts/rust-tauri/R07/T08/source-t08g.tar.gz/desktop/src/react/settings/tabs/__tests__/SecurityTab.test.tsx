// @vitest-environment jsdom

import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import React from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { useSettingsStore } from '../../store';

const autoSaveConfigMock = vi.fn();
const loadSettingsConfigMock = vi.fn();

vi.mock('../../helpers', () => ({
  autoSaveConfig: (...args: unknown[]) => autoSaveConfigMock(...args),
  t: (key: string) => ({
    'settings.security.sandbox': 'Sandbox',
    'settings.security.sandboxDesc': 'Run commands inside a sandbox.',
    'settings.security.sandboxNetwork': 'Sandbox network',
    'settings.security.sandboxNetworkDesc': 'Block network access when disabled.',
    'settings.security.sandboxNetworkDisabledDesc': 'Enable the command sandbox first.',
    'settings.security.sandboxNetworkWin32Unsupported': 'Windows command sandbox keeps network access and only isolates writes.',
    'settings.security.fileBackup': 'File backup',
    'settings.security.fileBackupDesc': 'Keep edit checkpoints.',
    'settings.security.archivedChats': 'Archived conversations',
    'settings.security.archivedChatsDesc': 'Review archived conversations.',
    'settings.security.viewArchivedChats': 'View archived conversations',
  } as Record<string, string>)[key] || key,
}));

vi.mock('../../actions', () => ({
  loadSettingsConfig: () => loadSettingsConfigMock(),
}));

vi.mock('../../api', () => ({
  lingxiFetch: vi.fn(),
}));

vi.mock('../../../hooks/use-i18n', () => ({
  useI18n: () => ({
    t: (key: string) => ({
      'session.archived.title': 'Archived conversations window',
      'session.archived.stats': '0 conversations',
      'session.archived.cleanup30': 'Clean 30 days',
      'session.archived.cleanup90': 'Clean 90 days',
      'session.archived.empty': 'No archived conversations',
      'common.loading': 'Loading',
    } as Record<string, string>)[key] || key,
  }),
}));

vi.mock('../../../stores/session-actions', () => ({
  listArchivedSessions: vi.fn(async () => []),
  restoreSession: vi.fn(),
  deleteArchivedSession: vi.fn(),
  cleanupArchivedSessions: vi.fn(),
  showSidebarToast: vi.fn(),
  loadSessions: vi.fn(),
}));

import { SecurityTab } from '../SecurityTab';
import { lingxiFetch } from '../../api';

describe('SecurityTab Windows sandbox network control', () => {
  beforeEach(() => {
    autoSaveConfigMock.mockResolvedValue(true);
    loadSettingsConfigMock.mockResolvedValue(undefined);
    useSettingsStore.setState({
      settingsConfig: {
        sandbox: true,
        sandbox_network: false,
        file_backup: { retention_days: 1 },
      },
      platformName: 'win32',
      currentAgentId: 'hana',
      settingsAgentId: 'hana',
    } as never);
  });

  afterEach(() => {
    cleanup();
    autoSaveConfigMock.mockReset();
    loadSettingsConfigMock.mockReset();
    useSettingsStore.setState({
      settingsConfig: null,
      platformName: null,
      currentAgentId: null,
      settingsAgentId: null,
      toastMessage: '',
      toastType: '',
      toastVisible: false,
    } as never);
  });

  it('disables the sandbox network switch on Windows and keeps it visually on', () => {
    render(React.createElement(SecurityTab));

    expect(screen.getByText('Windows command sandbox keeps network access and only isolates writes.')).toBeTruthy();

    const switches = screen.getAllByRole('switch') as HTMLButtonElement[];
    const networkSwitch = switches[1];
    expect(networkSwitch.disabled).toBe(true);
    expect(networkSwitch.getAttribute('aria-checked')).toBe('true');

    fireEvent.click(networkSwitch);
    expect(autoSaveConfigMock).not.toHaveBeenCalledWith({ sandbox_network: false }, expect.anything());
    expect(loadSettingsConfigMock).not.toHaveBeenCalled();
  });

  it('no longer renders the archived conversations entry (moved to the sidebar function row)', async () => {
    render(React.createElement(SecurityTab));

    // 入口迁移（用户裁决）：归档对话从设置→安全移到主界面侧栏功能行的垃圾桶按钮。
    expect(screen.queryByText('View archived conversations')).toBeNull();
    expect(screen.queryByText('Archived conversations window')).toBeNull();
  });

  it('does not render optimistic sandbox or backup states before settings config is ready', () => {
    useSettingsStore.setState({
      settingsConfig: null,
      platformName: 'darwin',
    } as never);

    render(React.createElement(SecurityTab));

    // 配置未就绪时只剩沙盒与联网沙盒两个开关：文件备份已改为恒开，不再有开关
    const switches = screen.getAllByRole('switch') as HTMLButtonElement[];
    expect(switches).toHaveLength(2);
    for (const item of switches) {
      expect(item.getAttribute('aria-checked')).toBe('mixed');
      expect(item.getAttribute('aria-busy')).toBe('true');
      expect(item.disabled).toBe(true);
      fireEvent.click(item);
    }
    expect(autoSaveConfigMock).not.toHaveBeenCalled();
    expect(loadSettingsConfigMock).not.toHaveBeenCalled();
  });
});


describe('SecurityTab archive read failures', () => {
  afterEach(() => { cleanup(); vi.mocked(lingxiFetch).mockReset(); });
  it('shows the first archive read failure with retry instead of no backups', async () => {
    vi.mocked(lingxiFetch).mockRejectedValueOnce(new Error('archive denied')).mockResolvedValueOnce({ json: async () => ({ checkpoints: [] }) } as Response);
    render(<SecurityTab />);
    fireEvent.click(screen.getByRole('button', { name: /settings.security.viewBackups/ }));
    await screen.findByRole('alert');
    expect(screen.queryByText('settings.security.noBackups')).toBeNull();
    fireEvent.click(screen.getByRole('button', { name: 'action.retry' }));
    await waitFor(() => expect(screen.getByText('settings.security.noBackups')).toBeTruthy());
    expect(screen.queryByRole('alert')).toBeNull();
  });
  it('keeps the last actual archive list when a later read fails', async () => {
    vi.mocked(lingxiFetch).mockResolvedValueOnce({ json: async () => ({ checkpoints: [{ id: 'old', ts: 1000, path: '/owned/old.txt', size: 3 }] }) } as Response).mockRejectedValueOnce(new Error('archive read failed'));
    render(<SecurityTab />);
    const toggle = () => screen.getByRole('button', { name: /settings.security.viewBackups/ });
    fireEvent.click(toggle()); await screen.findByText('/owned/old.txt');
    fireEvent.click(toggle()); fireEvent.click(toggle());
    await screen.findByRole('alert');
    expect(screen.getByText('/owned/old.txt')).toBeTruthy();
    expect(screen.queryByText('settings.security.noBackups')).toBeNull();
  });
});
