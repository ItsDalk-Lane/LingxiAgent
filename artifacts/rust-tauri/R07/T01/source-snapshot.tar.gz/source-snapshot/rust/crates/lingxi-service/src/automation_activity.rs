//! 活动页只投影正式触发、真实运行和统一历史；升格保留同一会话与原始谱系。
use crate::{Principal, ServiceState};
use axum::{
    extract::{Path, RawQuery, State},
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    Extension, Json,
};
use lingxi_adapters::storage::{
    automation as store, automation_activity as promotion, session_tree,
};
use serde_json::{json, Value};

struct ActivityError {
    status: StatusCode,
    code: &'static str,
    message: String,
}
impl ActivityError {
    fn new(status: StatusCode, code: &'static str, message: impl Into<String>) -> Self {
        Self {
            status,
            code,
            message: message.into(),
        }
    }
    fn storage(error: impl std::fmt::Debug) -> Self {
        Self::new(
            StatusCode::INTERNAL_SERVER_ERROR,
            "activity_read_failed",
            format!("{error:?}"),
        )
    }
    fn missing() -> Self {
        Self::new(
            StatusCode::NOT_FOUND,
            "activity_not_found",
            "activity not found",
        )
    }
    fn denied() -> Self {
        Self::new(
            StatusCode::FORBIDDEN,
            "activity_access_revoked",
            "activity authorization is unavailable",
        )
    }
    fn response(self) -> Response {
        (
            self.status,
            Json(json!({"error":self.code,"message":self.message})),
        )
            .into_response()
    }
}
struct ActivityRead {
    activity: Value,
    session_id: Option<String>,
    messages: Vec<Value>,
}

async fn check_session(
    state: &ServiceState,
    principal: &Principal,
    session: &str,
    agent: &str,
) -> Result<session_tree::SessionTreeRow, ActivityError> {
    match state
        .sessions()
        .get_for(principal, session)
        .await
        .map_err(ActivityError::storage)?
    {
        crate::sessions::SessionAccess::Ok(_) => {}
        crate::sessions::SessionAccess::NotFound => return Err(ActivityError::missing()),
        crate::sessions::SessionAccess::Forbidden => return Err(ActivityError::denied()),
    }
    let row = session_tree::get_session_row(state.storage(), session)
        .await
        .map_err(ActivityError::storage)?
        .ok_or_else(ActivityError::missing)?;
    if row.lifecycle != "active"
        || row.agent_id != agent
        || row.owner_user_id != lingxi_kernel::LOCAL_OWNER_SUBJECT
    {
        return Err(ActivityError::denied());
    }
    Ok(row)
}

async fn transcript(
    state: &ServiceState,
    principal: &Principal,
    session: &str,
) -> Result<Vec<Value>, ActivityError> {
    // 沿用正式历史投影，不能把后台输入重新制造成用户消息，也不重复加入流式正文。
    let response = crate::history::session_export_route(
        Extension(principal.clone()),
        State(state.clone()),
        Path(session.into()),
        RawQuery(None),
        HeaderMap::new(),
    )
    .await;
    if !response.status().is_success() {
        return Err(ActivityError::new(
            response.status(),
            "activity_session_unavailable",
            "activity history could not be read",
        ));
    }
    let bytes = axum::body::to_bytes(response.into_body(), usize::MAX)
        .await
        .map_err(ActivityError::storage)?;
    let history: Value = serde_json::from_slice(&bytes).map_err(ActivityError::storage)?;
    let items = history["items"]
        .as_array()
        .ok_or_else(|| ActivityError::storage("canonical history items missing"))?;
    let mut messages = Vec::new();
    for item in items {
        let (role, text) = match item["kind"].as_str() {
            Some("user_message") => ("user", item["text"].as_str().unwrap_or("").to_owned()),
            Some("final_message") => {
                let content = item["content"]
                    .as_array()
                    .ok_or_else(|| ActivityError::storage("canonical message content missing"))?;
                let text = content
                    .iter()
                    .filter(|block| block["type"] == "text")
                    .filter_map(|block| block["text"].as_str())
                    .collect::<String>();
                ("assistant", text)
            }
            _ => continue,
        };
        if !text.is_empty() {
            messages.push(json!({"role":role,"content":text}));
        }
    }
    Ok(messages)
}

async fn read_activity(
    state: &ServiceState,
    principal: &Principal,
    id: &str,
    include_promoted: bool,
) -> Result<ActivityRead, ActivityError> {
    if !principal.is_local_owner() {
        return Err(ActivityError::denied());
    }
    let trigger = store::get_trigger(state.storage(), id)
        .await
        .map_err(ActivityError::storage)?
        .ok_or_else(ActivityError::missing)?;
    if !include_promoted
        && promotion::get_promotion(state.storage(), id)
            .await
            .map_err(ActivityError::storage)?
            .is_some()
    {
        return Err(ActivityError::missing());
    }
    let authority=state.storage().query_one_text("SELECT json_object('studioId',studio_id,'actorId',actor_id,'ownerKind',owner_kind,'ownerSubject',owner_subject) FROM automation_jobs_v1 WHERE id=?1",vec![trigger.job_id.clone()]).await.map_err(ActivityError::storage)?.ok_or_else(ActivityError::missing)?;
    let authority: Value = serde_json::from_str(&authority).map_err(ActivityError::storage)?;
    if authority["studioId"] != state.management.identity_ids().1
        || authority["ownerKind"] != "local_user"
        || authority["ownerSubject"] != lingxi_kernel::LOCAL_OWNER_SUBJECT
    {
        return Err(ActivityError::denied());
    }
    let cfg: Value = serde_json::from_str(&trigger.config_json).map_err(ActivityError::storage)?;
    let activity_type = match cfg["origin"].as_str() {
        None | Some("cron") => "cron",
        Some("heartbeat") => "heartbeat",
        _ => return Err(ActivityError::missing()),
    };
    let agent = cfg["actorAgentId"]
        .as_str()
        .or_else(|| authority["actorId"].as_str())
        .ok_or_else(|| ActivityError::storage("activity actor missing"))?;
    if state
        .memory()
        .is_agent_deleted_checked(agent)
        .map_err(ActivityError::storage)?
    {
        return Err(ActivityError::denied());
    }
    let summaries = state
        .memory()
        .list_agent_summaries()
        .map_err(|error| ActivityError::storage(error.message))?;
    let agent_summary = summaries
        .iter()
        .find(|value| value["id"] == agent)
        .ok_or_else(ActivityError::denied)?;
    let agent_name = agent_summary["name"].as_str().unwrap_or(agent);
    let actual = store::get_trigger_run(state.storage(), id)
        .await
        .map_err(ActivityError::storage)?;
    let mut session_id = None;
    let mut messages = Vec::new();
    let mut started = trigger.created_at;
    let mut finished = None;
    let mut run_id = None;
    let mut error = trigger.error.clone();
    let status = if let Some((run, session, status)) = actual {
        if trigger.run_id.as_ref().is_some_and(|bound| bound != &run)
            || trigger
                .session_id
                .as_ref()
                .is_some_and(|bound| bound != &session)
        {
            return Err(ActivityError::storage(
                "activity run binding disagrees with durable cause",
            ));
        }
        let row = check_session(state, principal, &session, agent).await?;
        if let Some(source) = cfg
            .pointer("/executionContext/sourceSessionId")
            .and_then(Value::as_str)
        {
            let source = check_session(state, principal, source, agent).await?;
            if source.authorized_folders != row.authorized_folders {
                return Err(ActivityError::denied());
            }
        }
        let metadata=state.storage().query_one_text("SELECT json_object('startedAt',r.created_at_unix_ms,'updatedAt',r.updated_at_unix_ms,'terminalReason',r.terminal_reason,'origin',l.origin) FROM runs r JOIN run_lineage l ON l.run_id=r.run_id WHERE r.run_id=?1 AND r.session_id=?2",vec![run.clone(),session.clone()]).await.map_err(ActivityError::storage)?.ok_or_else(||ActivityError::storage("activity run disappeared"))?;
        let metadata: Value = serde_json::from_str(&metadata).map_err(ActivityError::storage)?;
        if metadata["origin"] != activity_type {
            return Err(ActivityError::storage(
                "activity origin disagrees with durable Run",
            ));
        }
        started = metadata["startedAt"]
            .as_i64()
            .ok_or_else(|| ActivityError::storage("activity start missing"))?;
        let terminal = [
            "completed",
            "failed",
            "cancelled",
            "interrupted_needs_attention",
        ]
        .contains(&status.as_str());
        if terminal {
            finished = metadata["updatedAt"].as_i64();
        }
        if error.is_none() {
            error = metadata["terminalReason"].as_str().map(str::to_owned);
        }
        messages = transcript(state, principal, &session).await?;
        // 读取期间撤销归属或授权时，不把刚读到的内容返回给调用者。
        let current = check_session(state, principal, &session, agent).await?;
        if let Some(source) = cfg
            .pointer("/executionContext/sourceSessionId")
            .and_then(Value::as_str)
        {
            let source = check_session(state, principal, source, agent).await?;
            if source.authorized_folders != current.authorized_folders {
                return Err(ActivityError::denied());
            }
        }
        if state
            .memory()
            .is_agent_deleted_checked(agent)
            .map_err(ActivityError::storage)?
        {
            return Err(ActivityError::denied());
        }
        session_id = Some(session);
        run_id = Some(run);
        match status.as_str() {
            "completed" => "done",
            "failed" => "error",
            "cancelled" => "cancelled",
            "interrupted_needs_attention" => "unknown",
            _ => "running",
        }
    } else {
        if let Some(source) = cfg
            .pointer("/executionContext/sourceSessionId")
            .and_then(Value::as_str)
        {
            check_session(state, principal, source, agent).await?;
        }
        match trigger.status {
            store::TriggerStatus::Claimed => "running",
            store::TriggerStatus::Running => "unknown",
            store::TriggerStatus::Succeeded => "unknown",
            store::TriggerStatus::Skipped => {
                finished = Some(trigger.updated_at);
                "skipped"
            }
            store::TriggerStatus::Failed => {
                finished = Some(trigger.updated_at);
                "error"
            }
            store::TriggerStatus::Cancelled => {
                finished = Some(trigger.updated_at);
                "cancelled"
            }
            store::TriggerStatus::Unknown => "unknown",
        }
    };
    let summary = messages
        .iter()
        .rev()
        .find(|message| message["role"] == "assistant")
        .and_then(|message| message["content"].as_str())
        .map(|text| text.chars().take(400).collect::<String>())
        .or_else(|| error.clone());
    let locator = session_id.as_deref().map(crate::session_locator::native);
    let activity = json!({"id":id,"type":activity_type,"label":cfg.get("label").filter(|value|value.is_string()),"agentId":agent,"agentName":agent_name,"summary":summary,"startedAt":started,"finishedAt":finished,"status":status,"error":error,"sessionFile":locator,"sessionPath":locator,"sessionId":session_id,"runId":run_id,"jobId":trigger.job_id,"triggerId":id});
    Ok(ActivityRead {
        activity,
        session_id,
        messages,
    })
}

/// 广播使用同一正式投影；没有可见活动时不能编造一条扁平更新。
pub(crate) async fn activity_for_trigger(
    state: &ServiceState,
    id: &str,
) -> Result<Option<Value>, String> {
    match read_activity(
        state,
        &crate::automation::local_owner_principal(),
        id,
        false,
    )
    .await
    {
        Ok(read) => Ok(Some(read.activity)),
        Err(error) if matches!(error.status, StatusCode::NOT_FOUND | StatusCode::FORBIDDEN) => {
            Ok(None)
        }
        Err(error) => Err(error.message),
    }
}

pub async fn list_route(
    State(state): State<ServiceState>,
    Extension(principal): Extension<Principal>,
) -> Response {
    if !principal.is_local_owner() {
        return ActivityError::denied().response();
    }
    let result = async {
        let triggers = store::list_trigger_history(
            state.storage(),
            None,
            usize::try_from(i64::MAX).map_err(ActivityError::storage)?,
        )
        .await
        .map_err(ActivityError::storage)?;
        let mut activities = Vec::new();
        for trigger in triggers {
            match read_activity(&state, &principal, &trigger.trigger_id, false).await {
                Ok(read) => activities.push(read.activity),
                Err(error)
                    if matches!(error.status, StatusCode::NOT_FOUND | StatusCode::FORBIDDEN) => {}
                Err(error) => return Err(error),
            }
        }
        activities.sort_by(|a, b| {
            b["startedAt"]
                .as_i64()
                .cmp(&a["startedAt"].as_i64())
                .then_with(|| a["id"].as_str().cmp(&b["id"].as_str()))
        });
        Ok(json!({"activities":activities}))
    }
    .await;
    match result {
        Ok(value) => Json(value).into_response(),
        Err(error) => error.response(),
    }
}

pub async fn session_route(
    State(state): State<ServiceState>,
    Extension(principal): Extension<Principal>,
    Path(id): Path<String>,
) -> Response {
    match read_activity(&state, &principal, &id, false).await {
        Ok(read) if read.session_id.is_some() => {
            Json(json!({"activity":read.activity,"messages":read.messages})).into_response()
        }
        Ok(_) => ActivityError::new(
            StatusCode::NOT_FOUND,
            "activity_session_unavailable",
            "no activity session",
        )
        .response(),
        Err(error) => error.response(),
    }
}

pub async fn promote_route(
    State(state): State<ServiceState>,
    Extension(principal): Extension<Principal>,
    Path(id): Path<String>,
) -> Response {
    let read = match read_activity(&state, &principal, &id, true).await {
        Ok(read) => read,
        Err(error) => return error.response(),
    };
    if read.session_id.is_none() {
        return ActivityError::new(
            StatusCode::NOT_FOUND,
            "activity_session_unavailable",
            "no activity session",
        )
        .response();
    }
    match state
        .session_admin()
        .promote_automation_activity(&principal, &id, state.clock().now_unix_ms())
        .await
    {
        Ok(session) => {
            Json(json!({"ok":true,"sessionPath":crate::session_locator::native(&session),"sessionId":session,"agentId":read.activity["agentId"]})).into_response()
        }
        Err(crate::session_admin::SessionAdminError::Busy) => ActivityError::new(
            StatusCode::CONFLICT,
            "session_busy",
            "activity is still running",
        )
        .response(),
        Err(crate::session_admin::SessionAdminError::NotFound) => {
            ActivityError::missing().response()
        }
        Err(error) => ActivityError::new(
            StatusCode::CONFLICT,
            "activity_promote_failed",
            format!("{error:?}"),
        )
        .response(),
    }
}
