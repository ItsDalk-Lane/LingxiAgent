import { useStore } from '../stores';
import { rustAutomationRoute } from '../services/rust-automation';
import { rustBridgeRoute } from '../services/rust-bridge';
import {
  appendConnectionAuth,
  buildConnectionUrl,
  requireServerConnection,
} from '../services/server-connection';

const DEFAULT_TIMEOUT = 30_000;
function skillRoute(connection: { serverNodeKind?: string }, path: string): string {
  return connection.serverNodeKind === 'lingxi-service' && (/^\/api\/skills(?:[/?]|$)/.test(path) || /^\/api\/agents\/[^/]+\/(?:skills|skill-bundles)\/[^/?]+(?:[?]|$)/.test(path)) ? `/lingxi/v1${path.slice('/api'.length)}` : rustBridgeRoute(connection, rustAutomationRoute(connection, path));
}

/**
 * 构建带认证的 LingxiAgent Server URL
 */
export function lingxiUrl(path: string): string {
  const connection = requireServerConnection(
    useStore.getState(),
    `lingxiUrl ${path}: server connection not ready`,
  );
  return buildConnectionUrl(connection, skillRoute(connection, path), { includeTokenQuery: true });
}

/**
 * 带认证的 fetch 封装
 * - 默认 30s 超时
 * - 自动校验 res.ok，非 2xx 抛错
 */
export async function lingxiFetch(
  path: string,
  opts: RequestInit & { timeout?: number; throwOnHttpError?: boolean } = {},
): Promise<Response> {
  const connection = requireServerConnection(
    useStore.getState(),
    `lingxiFetch ${path}: server connection not ready`,
  );
  const headers = appendConnectionAuth(connection, opts.headers);

  const {
    timeout = DEFAULT_TIMEOUT,
    signal: callerSignal,
    throwOnHttpError = true,
    ...fetchOpts
  } = opts;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  if (callerSignal) {
    if (callerSignal.aborted) controller.abort();
    else callerSignal.addEventListener('abort', () => controller.abort(), { once: true });
  }

  try {
    const res = await fetch(buildConnectionUrl(connection, skillRoute(connection, path)), {
      ...fetchOpts,
      headers,
      signal: controller.signal,
    });
    if (throwOnHttpError && !res.ok) {
      throw new Error(`lingxiFetch ${path}: ${res.status} ${res.statusText}`);
    }
    return res;
  } finally {
    clearTimeout(timer);
  }
}
