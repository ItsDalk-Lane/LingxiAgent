// 测试只读取本次隔离目录里的平台选择，不接触产品或用户配置。
import fs from 'node:fs';
import path from 'node:path';
export const options = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'platform-fixture.json'), 'utf8'));
export const platform = options.platform;
export const name = '平台公开昵称';
export const sender = platform === 'wechat' ? 'owner-native@fixture' : 'owner-native';
export const messageId = platform === 'wechat' ? '18446744073709551614' : `native-${platform}-message`;
export const inboundText = '四平台实际消息';
export function record(kind, data = {}) {
  fs.appendFileSync(path.join(process.cwd(), 'platform-operations.jsonl'), JSON.stringify({ platform, kind, ...data }) + '\n');
}
let sends = 0;
export function sent(text, target) {
  const id = `${platform}-native-send-${++sends}`;
  record('send', { messageId: id, text, target });
  return id;
}
