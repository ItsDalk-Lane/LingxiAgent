//! 正式 worker、四平台适配器、服务和 SQLite 闭环；只替换外部 SDK/HTTP/WebSocket 与模型响应。
use lingxi_kernel::{
    model_exchange::ModelTurnInput,
    ports::{
        ProviderDescriptor, ProviderTurn, ProviderTurnResult, TurnDeltaSink, TurnProviderPort,
    },
};
use lingxi_protocol::{ContentBlock, ModelCallId, NormalizedMessage};
use lingxi_service::{
    bridge_worker::BridgeWorkerLaunch, inject::ManualClock, prepare_layout, HomeSource,
    NetworkMode, ServiceConfig, ServiceDeps, ServiceState,
};
use lingxi_test_guard as _;
use serde_json::{json, Value};
use std::{
    path::PathBuf,
    sync::{
        atomic::{AtomicBool, AtomicUsize, Ordering},
        Arc,
    },
    time::Duration,
};

const REPLY: &str = "四平台真实闭环回答";
const PRIVATE_SECRET: &str = "PRIVATE-FIXTURE-CREDENTIAL";
#[derive(Default)]
struct Provider {
    calls: AtomicUsize,
    delayed: AtomicBool,
}
impl TurnProviderPort for Provider {
    fn descriptor(&self) -> ProviderDescriptor {
        ProviderDescriptor {
            provider: "r07.external.platform.fixture".into(),
            model: "synthetic".into(),
            operation: "chat".into(),
        }
    }
    fn next_turn<'a>(
        &'a self,
        ctx: &'a lingxi_kernel::RunContext,
        call: &'a ModelCallId,
        input: &'a ModelTurnInput,
        _sink: &'a dyn TurnDeltaSink,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ProviderTurnResult> + Send + 'a>> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        assert_eq!(input.submission, "四平台实际消息");
        Box::pin(async move {
            if self.delayed.load(Ordering::SeqCst) {
                tokio::time::sleep(Duration::from_millis(1200)).await;
            }
            ProviderTurnResult::of_ctx(
                ctx,
                ProviderTurn::Final {
                    message: NormalizedMessage {
                        role: "assistant".into(),
                        content: vec![ContentBlock::Text {
                            text: format!("<t> 10-16 09:30 </t>{REPLY}"),
                        }],
                        model_call_id: Some(call.clone()),
                    },
                },
            )
        })
    }
}
struct Harness {
    platform: &'static str,
    home: PathBuf,
    state: ServiceState,
    provider: Arc<Provider>,
    url: String,
    token: String,
    stop: tokio::sync::oneshot::Sender<()>,
    server: tokio::task::JoinHandle<()>,
}
impl Harness {
    async fn boot(platform: &'static str, existing: Option<PathBuf>) -> Self {
        let home = existing.unwrap_or_else(|| {
            std::env::temp_dir().join(format!(
                "r07-real-sdk-{platform}-{}",
                lingxi_adapters::storage::agent_memory::random_token_suffix()
            ))
        });
        std::fs::create_dir_all(home.join("agents/lingxi")).unwrap();
        std::fs::write(
            home.join("agents/lingxi/config.yaml"),
            "agent:\n  name: 四平台验证助手\nmemory:\n  enabled: false\n",
        )
        .unwrap();
        std::fs::write(
            home.join("platform-fixture.json"),
            json!({"platform":platform}).to_string(),
        )
        .unwrap();
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../..")
            .canonicalize()
            .unwrap();
        let home = home.canonicalize().unwrap();
        let layout = prepare_layout(&home).unwrap();
        let node = std::process::Command::new("which")
            .arg("node")
            .output()
            .unwrap();
        assert!(node.status.success());
        let provider = Arc::new(Provider::default());
        let state = ServiceState::bootstrap_with_deps(
            ServiceConfig {
                bind_addr: "127.0.0.1:0".parse().unwrap(),
                data_home: home.clone(),
                home_source: HomeSource::Cli,
                network_mode: NetworkMode::Loopback,
                shutdown_timeout_ms: 8000,
            },
            &layout,
            ServiceDeps {
                bridge_worker_launch: Some(BridgeWorkerLaunch {
                    program: PathBuf::from(String::from_utf8(node.stdout).unwrap().trim()),
                    args: vec![
                        "--import".into(),
                        root.join("tests/fixtures/r07-bridge-platforms/loader.mjs")
                            .to_string_lossy()
                            .into_owned(),
                        root.join("scripts/bridge-sdk-worker.ts")
                            .to_string_lossy()
                            .into_owned(),
                    ],
                    cwd: home.clone(),
                }),
                clock: Arc::new(ManualClock::new(1_800_000_000_000)),
                turn_provider: Some(provider.clone()),
                ..ServiceDeps::default()
            },
        )
        .await
        .unwrap();
        let token = state.auth().local_token();
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let url = format!("http://{}", listener.local_addr().unwrap());
        let (stop, stopped) = tokio::sync::oneshot::channel();
        let router = lingxi_service::build_router(state.clone());
        let server = tokio::spawn(async move {
            axum::serve(
                listener,
                router.into_make_service_with_connect_info::<std::net::SocketAddr>(),
            )
            .with_graceful_shutdown(async {
                let _ = stopped.await;
            })
            .await
            .unwrap();
        });
        let harness = Self {
            platform,
            home,
            state,
            provider,
            url,
            token,
            stop,
            server,
        };
        harness
            .request(
                "POST",
                "/lingxi/v1/bridge/settings",
                Some(json!({"receiptEnabled":false,"richStreamingEnabled":false})),
            )
            .await;
        harness.state.bridge().start(harness.state.clone());
        harness
    }
    async fn request(&self, method: &str, path: &str, body: Option<Value>) -> Value {
        let request = reqwest::Client::new()
            .request(method.parse().unwrap(), format!("{}{path}", self.url))
            .bearer_auth(&self.token);
        let response = if let Some(body) = body {
            request.json(&body)
        } else {
            request
        }
        .send()
        .await
        .unwrap();
        let status = response.status();
        let value: Value = response.json().await.unwrap();
        assert!(
            status.is_success(),
            "{} {path}: {status} {value}",
            self.platform
        );
        assert_ne!(value["ok"], false, "业务失败：{value}");
        value
    }
    fn sender(&self) -> &'static str {
        if self.platform == "wechat" {
            "owner-native@fixture"
        } else {
            "owner-native"
        }
    }
    async fn enable(&self) {
        let credentials = match self.platform {
            "feishu" => json!({"appId":"fixture-app","appSecret":PRIVATE_SECRET}),
            "dingtalk" => {
                json!({"corpId":"fixture-corp","clientId":"fixture-client","clientSecret":PRIVATE_SECRET,"robotCode":"fixture-robot"})
            }
            "qq" => json!({"appID":"fixture-app","appSecret":PRIVATE_SECRET}),
            "wechat" => json!({"botToken":PRIVATE_SECRET}),
            _ => unreachable!(),
        };
        self.request(
            "POST",
            "/lingxi/v1/bridge/config?agentId=lingxi",
            Some(json!({"platform":self.platform,"enabled":false,"credentials":credentials})),
        )
        .await;
        self.request(
            "POST",
            "/lingxi/v1/bridge/owner?agentId=lingxi",
            Some(json!({"platform":self.platform,"userId":self.sender()})),
        )
        .await;
        self.request(
            "POST",
            "/lingxi/v1/bridge/config?agentId=lingxi",
            Some(json!({"platform":self.platform,"enabled":true})),
        )
        .await;
    }
    async fn scalar(&self, sql: &str) -> String {
        self.state
            .storage()
            .query_one_text(sql, vec![])
            .await
            .unwrap()
            .unwrap()
    }
    async fn wait(&self, sql: &str, expected: &str) {
        tokio::time::timeout(Duration::from_secs(20), async {
            while self.scalar(sql).await != expected {
                tokio::time::sleep(Duration::from_millis(30)).await;
            }
        })
        .await
        .unwrap_or_else(|_| {
            panic!(
                "{} 未达到 {expected}: {sql}; operations={:?}",
                self.platform,
                self.operations()
            )
        });
    }
    fn operations(&self) -> Vec<Value> {
        std::fs::read_to_string(self.home.join("platform-operations.jsonl"))
            .unwrap_or_default()
            .lines()
            .map(|line| serde_json::from_str(line).unwrap())
            .collect()
    }
    async fn wait_connected(&self) {
        tokio::time::timeout(Duration::from_secs(15), async {
            loop {
                let status = self
                    .request("GET", "/lingxi/v1/bridge/status?agentId=lingxi", None)
                    .await;
                if status[self.platform]["status"] == "connected" {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(30)).await;
            }
        })
        .await
        .expect("重启后必须实际建立平台连接");
    }
    async fn close(self) -> PathBuf {
        self.state.bridge().stop();
        tokio::time::timeout(Duration::from_secs(12), self.state.bridge().wait_stopped())
            .await
            .unwrap()
            .unwrap();
        let _ = self.stop.send(());
        self.server.await.unwrap();
        self.state.storage().close().await.unwrap();
        self.home
    }
}

async fn platform_roundtrip(platform: &'static str) {
    let h = Harness::boot(platform, None).await;
    h.enable().await;
    h.wait(
        "SELECT CAST(COUNT(*) AS TEXT) FROM bridge_outbox_v1 WHERE status='confirmed'",
        "1",
    )
    .await;
    assert_eq!(
        h.scalar("SELECT CAST(COUNT(*) AS TEXT) FROM runs").await,
        "1"
    );
    assert_eq!(
        h.scalar("SELECT CAST(COUNT(*) AS TEXT) FROM bridge_inbox_v1")
            .await,
        "1"
    );
    assert_eq!(h.scalar("SELECT CAST(COUNT(*) AS TEXT) FROM bridge_inbox_v1 WHERE role='owner' AND status='succeeded'").await, "1");
    assert_eq!(h.provider.calls.load(Ordering::SeqCst), 1);
    let native_inbound = if platform == "wechat" {
        "18446744073709551614".into()
    } else {
        format!("native-{platform}-message")
    };
    assert_eq!(
        h.scalar("SELECT message_id FROM bridge_inbox_v1 LIMIT 1")
            .await,
        native_inbound
    );
    let receipt: Value = serde_json::from_str(
        &h.scalar("SELECT platform_receipt_json FROM bridge_outbox_v1 WHERE status='confirmed'")
            .await,
    )
    .unwrap();
    assert_eq!(receipt["platform"], platform);
    assert_eq!(
        receipt["messageIds"],
        json!([format!("{platform}-native-send-1")])
    );
    let operations = h.operations();
    let sends: Vec<_> = operations
        .iter()
        .filter(|operation| operation["kind"] == "send")
        .collect();
    assert_eq!(sends.len(), 1, "最终回复只能调用一次真实平台发送");
    assert_eq!(sends[0]["messageId"], receipt["messageIds"][0]);
    assert!(sends[0]["text"].as_str().unwrap().contains(REPLY));
    assert!(!operations
        .iter()
        .any(|operation| operation.to_string().contains("<t>")));
    let status = h
        .request("GET", "/lingxi/v1/bridge/status?agentId=lingxi", None)
        .await;
    assert_eq!(status[platform]["configured"], true);
    assert_eq!(status["owner"][platform], h.sender());
    let sessions = h
        .request(
            "GET",
            &format!("/lingxi/v1/bridge/sessions?agentId=lingxi&platform={platform}"),
            None,
        )
        .await;
    assert_eq!(sessions["sessions"].as_array().unwrap().len(), 1);
    assert_eq!(sessions["sessions"][0]["isOwner"], true);
    let public_name = sessions["sessions"][0]["displayName"]
        .as_str()
        .expect("会话必须保留公开名称");
    if platform == "wechat" {
        assert_eq!(public_name, "owner-native");
    } else {
        assert_eq!(public_name, "平台公开昵称");
    }
    let messages = h
        .request("GET", "/lingxi/v1/bridge/messages?agentId=lingxi", None)
        .await;
    for public in [&status, &sessions, &messages] {
        assert!(
            !public.to_string().contains("PRIVATE-"),
            "私密凭据或回复令牌泄漏到公开读面：{public}"
        );
    }
    let home = h.close().await;
    let restarted = Harness::boot(platform, Some(home)).await;
    restarted.wait_connected().await;
    restarted
        .wait("SELECT CAST(COUNT(*) AS TEXT) FROM bridge_inbox_v1", "1")
        .await;
    // 真实新 worker 再投同一消息，观察替身已经完成重投后再核验没有重建或外发。
    tokio::time::timeout(Duration::from_secs(15), async {
        while restarted
            .operations()
            .iter()
            .filter(|operation| operation["kind"] == "inbound")
            .count()
            < 2
        {
            tokio::time::sleep(Duration::from_millis(30)).await;
        }
    })
    .await
    .unwrap();
    tokio::time::sleep(Duration::from_millis(300)).await;
    assert_eq!(restarted.provider.calls.load(Ordering::SeqCst), 0);
    assert_eq!(
        restarted
            .scalar("SELECT CAST(COUNT(*) AS TEXT) FROM runs")
            .await,
        "1"
    );
    assert_eq!(
        restarted
            .operations()
            .iter()
            .filter(|operation| operation["kind"] == "send")
            .count(),
        1
    );
    let home = restarted.close().await;
    std::fs::remove_dir_all(home).unwrap();
}

#[tokio::test]
async fn actual_feishu_sdk_factory_roundtrip_and_restart_are_idempotent() {
    platform_roundtrip("feishu").await;
}
#[tokio::test]
async fn actual_dingtalk_sdk_factory_roundtrip_and_restart_are_idempotent() {
    platform_roundtrip("dingtalk").await;
}
#[tokio::test]
async fn actual_qq_sdk_factory_roundtrip_and_restart_are_idempotent() {
    platform_roundtrip("qq").await;
}
#[tokio::test]
async fn actual_wechat_sdk_factory_roundtrip_and_restart_are_idempotent() {
    platform_roundtrip("wechat").await;
}

#[tokio::test]
async fn actual_feishu_folded_preview_unknown_does_not_resend_content_as_a_new_final_reply() {
    let h = Harness::boot("feishu", None).await;
    h.provider.delayed.store(true, Ordering::SeqCst);
    std::fs::write(
        h.home.join("platform-fixture.json"),
        json!({"platform":"feishu","receiptUnknown":true}).to_string(),
    )
    .unwrap();
    h.request(
        "POST",
        "/lingxi/v1/bridge/settings",
        Some(json!({"receiptEnabled":true,"richStreamingEnabled":false})),
    )
    .await;
    h.enable().await;
    h.wait(
        "SELECT CAST(COUNT(*) AS TEXT) FROM bridge_outbox_v1 WHERE status='unknown'",
        "1",
    )
    .await;
    assert_eq!(h.provider.calls.load(Ordering::SeqCst), 1);
    assert_eq!(h.scalar("SELECT CAST(COUNT(*) AS TEXT) FROM bridge_effects_v1 WHERE operation='receipt_start' AND status='unknown'").await, "1");
    assert_eq!(
        h.scalar(
            "SELECT CAST(COUNT(*) AS TEXT) FROM bridge_effects_v1 WHERE operation='stream_finish'"
        )
        .await,
        "0"
    );
    let operations = h.operations();
    assert_eq!(
        operations
            .iter()
            .filter(|item| item["kind"] == "receipt_unknown")
            .count(),
        1
    );
    let published: Vec<_> = operations
        .iter()
        .filter(|item| item["kind"] == "send")
        .collect();
    assert!(
        published.is_empty(),
        "合并草稿可能已外发，未知后禁止另发新正文"
    );
    let home = h.close().await;
    std::fs::remove_dir_all(home).unwrap();
}

#[tokio::test]
async fn actual_dingtalk_adapter_recovers_from_a_transient_socket_error_without_reconfiguration() {
    let h = Harness::boot("dingtalk", None).await;
    std::fs::write(
        h.home.join("platform-fixture.json"),
        json!({"platform":"dingtalk","transientDrop":true}).to_string(),
    )
    .unwrap();
    h.enable().await;
    let original_generation = h
        .scalar("SELECT CAST(generation AS TEXT) FROM bridge_connectors_v1")
        .await;
    tokio::time::timeout(Duration::from_secs(3), async {
        loop {
            let status = h
                .request("GET", "/lingxi/v1/bridge/status?agentId=lingxi", None)
                .await;
            if matches!(
                status["dingtalk"]["status"].as_str(),
                Some("connecting" | "disconnected")
            ) && h
                .operations()
                .iter()
                .any(|item| item["kind"] == "network_disconnected")
            {
                break;
            }
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    })
    .await
    .expect("短暂掉线必须在管理页面明确可见");
    h.wait(
        "SELECT CAST(COUNT(*) AS TEXT) FROM bridge_outbox_v1 WHERE status='confirmed'",
        "1",
    )
    .await;
    assert_eq!(
        h.scalar("SELECT CAST(generation AS TEXT) FROM bridge_connectors_v1")
            .await,
        original_generation
    );
    assert_eq!(h.provider.calls.load(Ordering::SeqCst), 1);
    let operations = h.operations();
    assert_eq!(
        operations
            .iter()
            .filter(|item| item["kind"] == "network_disconnected")
            .count(),
        1
    );
    assert_eq!(
        operations
            .iter()
            .filter(|item| item["kind"] == "connect")
            .count(),
        2
    );
    let sends: Vec<_> = operations
        .iter()
        .filter(|item| item["kind"] == "send")
        .collect();
    assert_eq!(sends.len(), 1);
    assert!(sends[0]["text"].as_str().unwrap().contains(REPLY));
    let status = h
        .request("GET", "/lingxi/v1/bridge/status?agentId=lingxi", None)
        .await;
    assert_eq!(status["dingtalk"]["status"], "connected");
    let home = h.close().await;
    std::fs::remove_dir_all(home).unwrap();
}
