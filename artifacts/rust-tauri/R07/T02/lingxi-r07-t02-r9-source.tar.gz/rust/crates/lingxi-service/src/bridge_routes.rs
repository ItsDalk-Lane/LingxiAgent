//! 管理页面沿旧字段含义接入持久 Bridge 配置；读取只返回掩码。
use crate::ServiceState;
use axum::{
    extract::{Query, State},
    response::{IntoResponse, Response},
    Json,
};
use lingxi_adapters::storage::{agent_memory::config, bridge as store};
use serde::Deserialize;
use serde_json::{json, Value};

pub const PLATFORMS: [&str; 5] = ["telegram", "feishu", "dingtalk", "qq", "wechat"];
#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AgentQuery {
    agent_id: String,
    platform: Option<String>,
    limit: Option<usize>,
}
fn failure(error: impl ToString) -> Response {
    (
        axum::http::StatusCode::BAD_REQUEST,
        Json(json!({"ok":false,"error":error.to_string()})),
    )
        .into_response()
}
fn connector_id(state: &ServiceState, actor: &str, platform: &str) -> String {
    format!(
        "connector-{}",
        lingxi_kernel::session_tree::sha256_hex(
            json!([state.management.identity_ids().1, actor, platform])
                .to_string()
                .as_bytes()
        )
    )
}
pub(crate) fn credentials(platform: &str) -> &'static [&'static str] {
    match platform {
        "telegram" => &["token"],
        "feishu" => &["appId", "appSecret", "region"],
        "dingtalk" => &[
            "corpId",
            "clientId",
            "clientSecret",
            "robotCode",
            "apiBaseUrl",
            "authMode",
            "appKey",
            "appSecret",
            "restBaseUrl",
            "streamOpenUrl",
        ],
        "qq" => &["appID", "appId", "appSecret", "secret"],
        "wechat" => &["botToken", "token", "baseUrl", "apiBaseUrl", "accountId"],
        _ => &[],
    }
}
fn secret(key: &str) -> bool {
    matches!(
        key,
        "token" | "botToken" | "appSecret" | "clientSecret" | "secret"
    )
}
fn masked(value: &str) -> bool {
    value.starts_with("***") || value.starts_with('•')
}
fn actor_exists(state: &ServiceState, actor: &str) -> Result<(), String> {
    state
        .memory()
        .agent_dir_checked(actor)
        .map_err(|e| e.message)?;
    if state
        .memory()
        .is_agent_deleted_checked(actor)
        .map_err(|e| format!("{e:?}"))?
    {
        return Err("agent is deleted".into());
    }
    Ok(())
}
async fn old_config(state: &ServiceState, actor: &str, platform: &str) -> Result<Value, String> {
    let dir = state
        .memory()
        .agent_dir_checked(actor)
        .map_err(|e| e.message)?;
    let value = config::read_yaml_mapping_as_json(&dir.join("config.yaml"))
        .map_err(|e| e.to_string())?
        .unwrap_or_else(|| json!({}));
    Ok(value
        .get("bridge")
        .and_then(|row| row.get(platform))
        .filter(|row| row.is_object())
        .cloned()
        .unwrap_or_else(|| json!({})))
}
async fn configured(
    state: &ServiceState,
    actor: &str,
    platform: &str,
) -> Result<(Option<store::BridgeConnector>, Value), String> {
    let existing = store::get_connector(state.storage(), &connector_id(state, actor, platform))
        .await
        .map_err(|e| e.to_string())?;
    let config = match &existing {
        Some(row) => serde_json::from_str(&row.input.config_json)
            .map_err(|_| "Bridge configuration damaged".to_string())?,
        None => old_config(state, actor, platform).await?,
    };
    Ok((existing, config))
}
fn permission(state: &ServiceState) -> Result<Value, String> {
    let root = state.memory().read_preferences_root()?;
    let mode = root
        .pointer("/bridge/permissionMode")
        .and_then(Value::as_str)
        .unwrap_or_else(|| {
            if root["bridge_read_only"] == true {
                "read_only"
            } else {
                "auto"
            }
        });
    if !matches!(mode, "auto" | "read_only" | "operate") {
        return Err("Bridge permission mode is invalid".into());
    }
    Ok(
        json!({"permissionMode":mode,"readOnly":mode=="read_only","receiptEnabled":root.pointer("/bridge/receiptEnabled")!=Some(&Value::Bool(false)),"richStreamingEnabled":root.pointer("/bridge/richStreamingEnabled")!=Some(&Value::Bool(false))}),
    )
}
pub(crate) async fn status(state: &ServiceState, actor: &str) -> Result<Value, String> {
    actor_exists(state, actor)?;
    let mut value = permission(state)?;
    value["agentId"] = json!(actor);
    value["owner"] = json!({});
    value["knownUsers"] = json!({});
    value["bridgeReady"] = json!(true);
    value["bridgeInitializing"] = json!(false);
    value["bridgeError"] = Value::Null;
    for platform in PLATFORMS {
        let (existing, config) = configured(state, actor, platform).await?;
        let mut item = state
            .bridge()
            .status_value(&connector_id(state, actor, platform));
        item["agentId"] = json!(actor);
        item["enabled"] = json!(existing
            .as_ref()
            .map(|row| row.input.enabled)
            .unwrap_or(config["enabled"] == true));
        let present = |keys: &[&str]| {
            keys.iter().any(|key| {
                config[*key]
                    .as_str()
                    .is_some_and(|s| !s.trim().is_empty() && !masked(s))
            })
        };
        item["configured"] = json!(match platform {
            "telegram" => present(&["token"]),
            "wechat" => present(&["botToken", "token"]),
            "feishu" => present(&["appId"]) && present(&["appSecret"]),
            "dingtalk" =>
                present(&["clientId", "appKey"]) && present(&["clientSecret", "appSecret"]),
            "qq" => present(&["appID", "appId"]) && present(&["appSecret", "secret"]),
            _ => false,
        });
        for key in credentials(platform) {
            if let Some(field) = config.get(*key) {
                if secret(key) {
                    let present = field.as_str().is_some_and(|s| !s.is_empty());
                    item[*key] = json!(if present { "********" } else { "" });
                    item[match *key {
                        "token" => "hasToken",
                        "botToken" => "hasBotToken",
                        "clientSecret" => "hasClientSecret",
                        _ => "hasAppSecret",
                    }] = json!(present);
                } else {
                    item[*key] = field.clone();
                }
            }
        }
        if platform == "wechat" {
            // 保留现有设置页的已登录含义，公开值始终为掩码。
            let present = present(&["botToken", "token"]);
            item["hasToken"] = json!(present);
            item["token"] = json!(if present { "********" } else { "" });
        }
        value[platform] = item;
        value["owner"][platform] = json!(existing
            .and_then(|row| row.input.owner_sender_id)
            .or_else(|| config["owner"]
                .as_str()
                .filter(|s| !s.is_empty())
                .map(str::to_string)));
        value["knownUsers"][platform] = json!([]);
    }
    value["whatsapp"] = json!({"status":"unsupported","enabled":false,"error":"not part of the five-platform runtime"});
    // 已识别发送者只展示公开身份，不返回平台回复令牌或原始正文。
    let users = lingxi_adapters::storage::bridge_reads::known_senders(state.storage(), actor)
        .await
        .map_err(|e| e.to_string())?;
    for user in users {
        if let Some(users) = value["knownUsers"][&user.platform].as_array_mut() {
            users.push(json!({"userId":user.user_id,"displayName":user.user_id}));
        }
    }
    Ok(value)
}
pub async fn status_route(
    State(state): State<ServiceState>,
    Query(query): Query<AgentQuery>,
) -> Response {
    match status(&state, &query.agent_id).await {
        Ok(value) => Json(value).into_response(),
        Err(error) => failure(error),
    }
}
#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ConfigRequest {
    platform: String,
    credentials: Option<Value>,
    enabled: Option<bool>,
}
async fn save(
    state: &ServiceState,
    actor: &str,
    platform: &str,
    patch: Option<Value>,
    enabled: Option<bool>,
    owner: Option<Option<String>>,
) -> Result<(), String> {
    actor_exists(state, actor)?;
    if !PLATFORMS.contains(&platform) {
        return Err("invalid platform".into());
    }
    let (existing, mut config) = configured(state, actor, platform).await?;
    let object = config
        .as_object_mut()
        .ok_or("Bridge configuration must be an object")?;
    let aliases: &[(&str, &str)] = match platform {
        "qq" => &[("appId", "appID"), ("secret", "appSecret")],
        "wechat" => &[("token", "botToken"), ("apiBaseUrl", "baseUrl")],
        _ => &[],
    };
    for (alias, canonical) in aliases {
        if let Some(value) = object.remove(*alias) {
            object.entry((*canonical).to_owned()).or_insert(value);
        }
    }
    if let Some(patch) = patch {
        let patch = patch
            .as_object()
            .ok_or("Bridge credentials must be an object")?;
        for (key, value) in patch {
            if !credentials(platform).contains(&key.as_str()) {
                return Err(format!("unsupported {platform} credential field"));
            }
            let key = aliases
                .iter()
                .find_map(|(alias, canonical)| (*alias == key).then_some(*canonical))
                .unwrap_or(key);
            if !value.is_string() && !value.is_null() {
                return Err("Bridge credential fields must be strings".into());
            }
            if value.as_str().is_some_and(|s| s.len() > 16 * 1024) {
                return Err("Bridge credential exceeds budget".into());
            }
            if secret(key) && value.as_str().is_some_and(masked) {
                if !object
                    .get(key)
                    .and_then(Value::as_str)
                    .is_some_and(|s| !s.is_empty())
                {
                    return Err("masked credential has no stored value".into());
                }
                continue;
            }
            if value.is_null() {
                object.remove(key);
            } else {
                object.insert(key.to_owned(), value.clone());
            }
        }
    }
    let enabled = enabled.unwrap_or_else(|| {
        existing
            .as_ref()
            .map(|row| row.input.enabled)
            .unwrap_or(object.get("enabled") == Some(&Value::Bool(true)))
    });
    let owner = owner.unwrap_or_else(|| {
        existing
            .as_ref()
            .and_then(|row| row.input.owner_sender_id.clone())
            .or_else(|| {
                object
                    .get("owner")
                    .and_then(Value::as_str)
                    .filter(|s| !s.is_empty())
                    .map(str::to_string)
            })
    });
    object.remove("owner");
    object.remove("enabled");
    if enabled {
        let required = match platform {
            "telegram" => vec!["token"],
            "wechat" => vec!["botToken"],
            "feishu" => vec!["appId", "appSecret"],
            "dingtalk" => vec!["clientId", "clientSecret"],
            "qq" => vec!["appID", "appSecret"],
            _ => vec![],
        };
        for key in required {
            let aliases = match key {
                "botToken" => vec!["botToken", "token"],
                "clientId" => vec!["clientId", "appKey"],
                "clientSecret" => vec!["clientSecret", "appSecret"],
                "appID" => vec!["appID", "appId"],
                "appSecret" if platform == "qq" => vec!["appSecret", "secret"],
                _ => vec![key],
            };
            if !aliases.iter().any(|key| {
                object
                    .get(*key)
                    .and_then(Value::as_str)
                    .is_some_and(|s| !s.trim().is_empty() && !masked(s))
            }) {
                return Err(format!("{platform} {key} is required"));
            }
        }
    }
    let input = store::BridgeConnectorInput {
        id: connector_id(state, actor, platform),
        platform: platform.into(),
        studio_id: state.management.identity_ids().1,
        actor_id: actor.into(),
        owner_subject: lingxi_kernel::LOCAL_OWNER_SUBJECT.into(),
        owner_sender_id: owner,
        enabled,
        config_json: config.to_string(),
    };
    store::put_connector(
        state.storage(),
        &input,
        existing.as_ref().map(|row| row.generation),
        state.clock().now_unix_ms(),
    )
    .await
    .map_err(|e| e.to_string())?;
    Ok(())
}
pub async fn config_route(
    State(state): State<ServiceState>,
    Query(query): Query<AgentQuery>,
    Json(body): Json<ConfigRequest>,
) -> Response {
    match save(
        &state,
        &query.agent_id,
        &body.platform,
        body.credentials,
        body.enabled,
        None,
    )
    .await
    {
        Ok(()) => match status(&state, &query.agent_id).await {
            Ok(value) => Json(json!({"ok":true,"status":value})).into_response(),
            Err(error) => failure(error),
        },
        Err(error) => failure(error),
    }
}
#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct OwnerRequest {
    platform: String,
    user_id: Option<String>,
}
pub async fn owner_route(
    State(state): State<ServiceState>,
    Query(query): Query<AgentQuery>,
    Json(body): Json<OwnerRequest>,
) -> Response {
    let owner = body.user_id.filter(|s| !s.is_empty());
    match save(
        &state,
        &query.agent_id,
        &body.platform,
        None,
        None,
        Some(owner),
    )
    .await
    {
        Ok(()) => match status(&state, &query.agent_id).await {
            Ok(value) => Json(json!({"ok":true,"status":value})).into_response(),
            Err(error) => failure(error),
        },
        Err(error) => failure(error),
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct StopRequest {
    platform: String,
}
pub async fn stop_route(
    State(state): State<ServiceState>,
    Query(query): Query<AgentQuery>,
    Json(body): Json<StopRequest>,
) -> Response {
    match save(
        &state,
        &query.agent_id,
        &body.platform,
        None,
        Some(false),
        None,
    )
    .await
    {
        Ok(()) => Json(json!({"ok":true})).into_response(),
        Err(error) => failure(error),
    }
}
#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct SettingsRequest {
    permission_mode: Option<String>,
    read_only: Option<bool>,
    receipt_enabled: Option<bool>,
    rich_streaming_enabled: Option<bool>,
}
pub async fn settings_route(
    State(state): State<ServiceState>,
    Json(body): Json<SettingsRequest>,
) -> Response {
    let result = (|| -> Result<Value, String> {
        let _guard = crate::agents_admin::preferences_locked();
        let mut root = state.memory().read_preferences_root()?;
        let mode = body.permission_mode.or_else(|| {
            body.read_only.map(|value| {
                if value {
                    "read_only".into()
                } else {
                    "auto".into()
                }
            })
        });
        if let Some(mode) = mode {
            if !matches!(mode.as_str(), "auto" | "read_only" | "operate") {
                return Err("invalid Bridge permission mode".into());
            }
            root["bridge"]["permissionMode"] = json!(mode);
        }
        if let Some(value) = body.receipt_enabled {
            root["bridge"]["receiptEnabled"] = json!(value);
        }
        if let Some(value) = body.rich_streaming_enabled {
            root["bridge"]["richStreamingEnabled"] = json!(value);
        }
        state.memory().write_preferences_root(&root)?;
        permission(&state)
    })();
    match result {
        Ok(mut value) => {
            value["ok"] = json!(true);
            Json(value).into_response()
        }
        Err(error) => failure(error),
    }
}
pub async fn messages_route(
    State(state): State<ServiceState>,
    Query(query): Query<AgentQuery>,
) -> Response {
    if let Err(error) = actor_exists(&state, &query.agent_id) {
        return failure(error);
    }
    match lingxi_adapters::storage::bridge_reads::messages(
        state.storage(),
        &query.agent_id,
        query.limit.unwrap_or(50),
    )
    .await
    {
        Ok(messages) => Json(json!({"messages":messages})).into_response(),
        Err(error) => failure(error),
    }
}
pub async fn sessions_route(
    State(state): State<ServiceState>,
    Query(query): Query<AgentQuery>,
) -> Response {
    if let Err(error) = actor_exists(&state, &query.agent_id) {
        return failure(error);
    }
    match lingxi_adapters::storage::bridge_reads::sessions(
        state.storage(),
        &query.agent_id,
        query.platform.as_deref(),
    )
    .await
    {
        Ok(sessions) => Json(json!({"sessions":sessions})).into_response(),
        Err(error) => failure(error),
    }
}

/// 首次接入只创建尚不存在的连接记录；已有配置、撤权和禁用结果不会被旧文件覆盖。
pub(crate) async fn import_existing(state: &ServiceState) -> Result<(), String> {
    let agents = state
        .memory()
        .list_agent_summaries()
        .map_err(|error| format!("Bridge agent list unavailable: {}", error.message))?;
    for agent in agents {
        let actor = agent["id"]
            .as_str()
            .ok_or("Bridge agent identity missing")?;
        for platform in PLATFORMS {
            if store::get_connector(state.storage(), &connector_id(state, actor, platform))
                .await
                .map_err(|e| e.to_string())?
                .is_some()
            {
                continue;
            }
            let config = old_config(state, actor, platform).await?;
            if config.as_object().is_none_or(|row| row.is_empty()) {
                continue;
            }
            save(state, actor, platform, None, None, None).await?;
        }
    }
    Ok(())
}

pub(crate) fn worker_config(platform: &str, source: &Value, actor: &str) -> Result<Value, String> {
    let mut value = json!({"agentId":actor});
    for key in credentials(platform) {
        if let Some(field) = source.get(*key) {
            value[*key] = field.clone();
        }
    }
    match platform {
        "qq" => {
            if value["appID"].is_null() {
                value["appID"] = value["appId"].clone();
            }
            if value["appSecret"].is_null() {
                value["appSecret"] = value["secret"].clone();
            }
            value
                .as_object_mut()
                .ok_or("Bridge config damaged")?
                .remove("appId");
            value
                .as_object_mut()
                .ok_or("Bridge config damaged")?
                .remove("secret");
        }
        "wechat" => {
            if value["botToken"].is_null() {
                value["botToken"] = value["token"].clone();
            }
            value
                .as_object_mut()
                .ok_or("Bridge config damaged")?
                .remove("token");
        }
        _ => {}
    }
    Ok(value)
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct TestRequest {
    platform: String,
    credentials: Option<Value>,
    #[serde(default)]
    use_saved_credentials: bool,
}
pub async fn test_route(
    State(state): State<ServiceState>,
    Query(query): Query<AgentQuery>,
    Json(body): Json<TestRequest>,
) -> Response {
    let result = async {
        actor_exists(&state, &query.agent_id)?;
        if !PLATFORMS.contains(&body.platform.as_str()) {
            return Err("invalid platform".to_string());
        }
        let mut config = if body.use_saved_credentials {
            configured(&state, &query.agent_id, &body.platform).await?.1
        } else {
            if body.credentials.is_none() {
                return Err("platform and credentials required".into());
            }
            json!({})
        };
        if let Some(patch) = body.credentials {
            let patch = patch
                .as_object()
                .ok_or("Bridge credentials must be an object")?;
            for (key, value) in patch {
                if !credentials(&body.platform).contains(&key.as_str()) || !value.is_string() {
                    return Err("invalid credential field".into());
                }
                if secret(key) && value.as_str().is_some_and(masked) {
                    if !body.use_saved_credentials {
                        return Err("masked credentials require useSavedCredentials=true".into());
                    }
                    continue;
                }
                config[key] = value.clone();
            }
        }
        let config = worker_config(&body.platform, &config, &query.agent_id)?;
        state
            .bridge()
            .diagnostic(lingxi_protocol::BridgeDiagnosticCommand::Verify {
                platform: body.platform,
                config,
            })
            .await
    }
    .await;
    diagnostic_response(result)
}
fn diagnostic_response(result: Result<Value, String>) -> Response {
    match result {
        Ok(mut value) => {
            if let Some(object) = value.as_object_mut() {
                object.remove("kind");
            }
            Json(value).into_response()
        }
        Err(error) => failure(error),
    }
}
pub async fn qrcode_route(State(state): State<ServiceState>) -> Response {
    diagnostic_response(
        state
            .bridge()
            .diagnostic(lingxi_protocol::BridgeDiagnosticCommand::WechatQrcode)
            .await,
    )
}
#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct QrcodeStatusRequest {
    qrcode_id: String,
}
pub async fn qrcode_status_route(
    State(state): State<ServiceState>,
    Json(body): Json<QrcodeStatusRequest>,
) -> Response {
    if body.qrcode_id.trim().is_empty()
        || body.qrcode_id.len() > 4096
        || body.qrcode_id.contains('\0')
    {
        return failure("invalid QR code identity");
    }
    diagnostic_response(
        state
            .bridge()
            .diagnostic(
                lingxi_protocol::BridgeDiagnosticCommand::WechatQrcodeStatus {
                    qrcode_id: body.qrcode_id,
                },
            )
            .await,
    )
}
